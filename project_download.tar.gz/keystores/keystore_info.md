# NBA Point Guard Clock - Keystore Information

IMPORTANT: Keep this information secure. If you lose this information, you will not be able to update your app on the Play Store.

## Keystore Details

- **Keystore File Location:** `keystores/android.keystore`
- **Keystore Type:** PKCS12
- **Creation Date:** April 23, 2025

## Access Credentials

- **Keystore Password:** `NBAcl0ck!S3cur3`
- **Key Alias:** `nbapgclock`
- **Key Password:** `NBAcl0ck!S3cur3`

## Certificate Information

- **Owner:** CN=NBA PG Clock App, OU=Development, O=NBA PG Clock, L=Basketball City, ST=CA, C=US
- **Validity:** April 23, 2025 until September 8, 2052 (10,000 days)
- **Key Type:** 2048-bit RSA key
- **Signature Algorithm:** SHA256withRSA

## How to Use This Keystore

When building your Android app for release:

1. In Android Studio: 
   - Go to Build > Generate Signed Bundle/APK
   - Select Android App Bundle or APK
   - Browse to `keystores/android.keystore`
   - Enter the keystore password and key password as provided above
   - Select the alias `nbapgclock`

2. Via Command Line:
   ```
   jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore keystores/android.keystore -storepass NBAcl0ck!S3cur3 app-release-unsigned.apk nbapgclock
   ```

## Backup Instructions

1. Save a copy of the keystore file in at least 2 secure locations (cloud storage, USB drive, etc.)
2. Save this information document securely (password manager recommended)
3. Never share the keystore or its passwords with unauthorized parties

## Already Configured in Capacitor

The keystore path is already configured in your `capacitor.config.ts` file:

```typescript
android: {
  buildOptions: {
    keystorePath: "keystores/android.keystore",
    keystoreAlias: "nbapgclock",
  }
}
```

Note: The passwords are not stored in this file for security reasons. You will need to provide them when building your app.