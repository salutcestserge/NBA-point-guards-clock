#!/bin/bash

# Ensure the web app is built first
echo "Building web application..."
npm run build

# Sync the web assets to the Android project
echo "Syncing to Android..."
npx cap sync android

# Create directory for the output
mkdir -p builds/android

# Build the debug APK
echo "Building debug APK..."
cd android
./gradlew assembleDebug

# Copy the APK to an easy-to-find location
echo "Copying APK to builds/android directory..."
cp app/build/outputs/apk/debug/app-debug.apk ../builds/android/nba-pg-clock-debug.apk

echo "Debug APK built at builds/android/nba-pg-clock-debug.apk"