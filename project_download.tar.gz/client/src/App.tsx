import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import AlarmManager from "@/components/AlarmManager";
import { ClockSettingsProvider } from "@/contexts/ClockSettingsContext";
import { AlarmProvider } from "@/contexts/AlarmContext";
import { TimerProvider } from "@/contexts/TimerContext";
import { DarkModeProvider } from "@/contexts/DarkModeContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ClockSettingsProvider>
        <DarkModeProvider>
          <AlarmProvider>
            <TimerProvider>
              <AlarmManager />
              <Router />
            </TimerProvider>
          </AlarmProvider>
        </DarkModeProvider>
      </ClockSettingsProvider>
    </QueryClientProvider>
  );
}

export default App;
