import { useEffect, useState, useRef } from 'react';
import { useAlarms } from '@/contexts/AlarmContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Bell, BellOff } from 'lucide-react';

// Define AlarmData type for our component
interface AlarmData {
  id: number;
  userId: number | null;
  time: string;
  label: string;
  days: string;
  enabled: boolean | null;
  createdAt: string | Date;
}

// We'll use AudioContext to create a sound instead of an external file
const generateAlarmSound = (audioContext: AudioContext) => {
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  
  oscillator.type = 'square';
  oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);
  
  // Make the sound pulse
  const pulseSpeed = 0.5; // Slower pulsing
  gainNode.gain.setValueAtTime(0, audioContext.currentTime);
  
  // Create a pulsing effect
  const pulse = () => {
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.8, audioContext.currentTime + 0.1);
    gainNode.gain.exponentialRampToValueAtTime(0.1, audioContext.currentTime + pulseSpeed);
  };
  
  oscillator.start();
  pulse();
  
  // Pulse every `pulseSpeed` seconds
  const interval = setInterval(pulse, pulseSpeed * 1000);
  
  return {
    oscillator,
    gainNode,
    stop: () => {
      clearInterval(interval);
      oscillator.stop();
      oscillator.disconnect();
      gainNode.disconnect();
    }
  };
};

export default function AlarmManager() {
  const { alarms } = useAlarms();
  const { toast } = useToast();
  const [activeAlarm, setActiveAlarm] = useState<AlarmData | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const alarmSoundRef = useRef<ReturnType<typeof generateAlarmSound> | null>(null);

  // Initialize audio context on first user interaction
  // (browsers require user gesture to create AudioContext)
  useEffect(() => {
    const initAudio = () => {
      if (!audioContext) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        setAudioContext(ctx);
      }
    };
    
    // Add event listener to initialize on first click
    document.addEventListener('click', initAudio, { once: true });
    
    return () => {
      document.removeEventListener('click', initAudio);
      // Clean up the audio context if needed
      if (audioContext) {
        if (alarmSoundRef.current) {
          alarmSoundRef.current.stop();
          alarmSoundRef.current = null;
        }
      }
    };
  }, [audioContext]);

  // Check for alarms each minute
  useEffect(() => {
    if (!alarms.length) return;

    const checkAlarms = () => {
      const now = new Date();
      const currentHour = now.getHours().toString().padStart(2, '0');
      const currentMinute = now.getMinutes().toString().padStart(2, '0');
      const currentTime = `${currentHour}:${currentMinute}`;
      const currentDay = now.getDay().toString();

      // Check if any alarm should trigger
      alarms.forEach(alarm => {
        if (
          alarm.enabled &&
          alarm.time === currentTime &&
          alarm.days.split(',').includes(currentDay) &&
          !activeAlarm
        ) {
          triggerAlarm(alarm);
        }
      });
    };

    // Check immediately and then every minute
    checkAlarms();
    const intervalId = setInterval(checkAlarms, 60000);

    return () => clearInterval(intervalId);
  }, [alarms, activeAlarm]);

  // Play alarm sound using AudioContext
  useEffect(() => {
    if (activeAlarm && !isPlaying && audioContext) {
      try {
        alarmSoundRef.current = generateAlarmSound(audioContext);
        setIsPlaying(true);
      } catch (err) {
        console.error('Failed to play alarm sound:', err);
      }
    } else if (!activeAlarm && isPlaying && alarmSoundRef.current) {
      alarmSoundRef.current.stop();
      alarmSoundRef.current = null;
      setIsPlaying(false);
    }
  }, [activeAlarm, isPlaying, audioContext]);

  const triggerAlarm = (alarm: AlarmData) => {
    setActiveAlarm(alarm);
    
    // Show notification toast
    toast({
      title: 'Alarm: ' + alarm.label,
      description: `It's ${alarm.time}`,
      action: (
        <Button 
          variant="outline" 
          size="sm" 
          onClick={dismissAlarm}
          className="mt-2"
        >
          <BellOff className="h-4 w-4 mr-1" />
          Dismiss
        </Button>
      ),
      duration: 60000, // Long duration
    });
  };

  const dismissAlarm = () => {
    if (alarmSoundRef.current) {
      alarmSoundRef.current.stop();
      alarmSoundRef.current = null;
    }
    setIsPlaying(false);
    setActiveAlarm(null);
  };

  // This component doesn't render anything visible
  // but manages alarm functionality in the background
  return <></>;
}