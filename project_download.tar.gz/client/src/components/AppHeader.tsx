import { useState } from "react";
import { Menu } from "lucide-react";
import { Link } from "wouter";

const AppHeader = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  return (
    <header className="bg-nba-blue shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <a className="text-white font-oswald text-2xl font-bold">NBA CLOCK CHALLENGE</a>
          </Link>
          <div className="ml-2 bg-nba-gold px-2 py-1 rounded text-xs font-bold text-nba-blue">POINT GUARDS</div>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/">
            <a className="text-white hover:text-nba-gold transition-colors font-medium">Home</a>
          </Link>
          <a href="#about" className="text-white hover:text-nba-gold transition-colors font-medium">About</a>
          <a href="#featured" className="text-white hover:text-nba-gold transition-colors font-medium">Featured Guards</a>
          <a href="#download" className="text-white hover:text-nba-gold transition-colors font-medium">Download</a>
        </nav>
        
        <div className="flex items-center space-x-2">
          <button
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-nba-blue border-t border-blue-800">
          <div className="container mx-auto px-4 py-2">
            <nav className="flex flex-col space-y-2">
              <Link href="/">
                <a className="text-white hover:text-nba-gold transition-colors font-medium py-2">Home</a>
              </Link>
              <a href="#about" className="text-white hover:text-nba-gold transition-colors font-medium py-2">About</a>
              <a href="#featured" className="text-white hover:text-nba-gold transition-colors font-medium py-2">Featured Guards</a>
              <a href="#download" className="text-white hover:text-nba-gold transition-colors font-medium py-2">Download</a>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default AppHeader;
