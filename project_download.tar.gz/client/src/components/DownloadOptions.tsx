import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Share2 } from "lucide-react";
import { saveAs } from "file-saver";
import { useToast } from "@/hooks/use-toast";

const DownloadOptions = () => {
  const [isDownloading, setIsDownloading] = useState(false);
  const { toast } = useToast();

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      // Access the export function from Clock component
      const exportFn = (window as any).exportClockAsImage;
      if (!exportFn) {
        throw new Error("Export function not available");
      }
      
      const dataUrl = await exportFn();
      if (!dataUrl) {
        throw new Error("Failed to generate image");
      }
      
      // Convert data URL to Blob
      const blob = await (await fetch(dataUrl)).blob();
      
      // Download using FileSaver
      saveAs(blob, "nba-point-guard-clock.png");
      
      toast({
        title: "Download successful",
        description: "Your NBA Point Guard Clock has been saved!",
      });
    } catch (error) {
      console.error("Download error:", error);
      toast({
        title: "Download failed",
        description: "There was an error downloading your clock. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "NBA Point Guard Clock",
        text: "Check out this interactive NBA Point Guard Clock!",
        url: window.location.href,
      })
      .then(() => {
        toast({
          title: "Shared successfully",
          description: "Thank you for sharing the NBA Point Guard Clock!",
        });
      })
      .catch((error) => {
        console.error("Share error:", error);
        toast({
          title: "Share failed",
          description: "There was an error sharing. Please try again.",
          variant: "destructive",
        });
      });
    } else {
      // Fallback to copying link to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied to clipboard",
        description: "Share this link with your friends!",
      });
    }
  };

  return (
    <div className="mt-6">
      <h3 className="font-medium text-gray-800 mb-3">Download Options:</h3>
      <div className="flex flex-col space-y-3">
        <Button 
          onClick={handleDownload}
          disabled={isDownloading}
          className="bg-nba-blue hover:bg-blue-800 text-white"
        >
          <Download className="h-4 w-4 mr-2" />
          {isDownloading ? "Processing..." : "Download as Image"}
        </Button>
        
        <Button 
          onClick={handleShare}
          variant="outline"
          className="border-nba-blue text-nba-blue hover:bg-blue-50"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Share Clock
        </Button>
      </div>
    </div>
  );
};

export default DownloadOptions;
