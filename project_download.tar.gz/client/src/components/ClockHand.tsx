interface ClockHandProps {
  type: 'hour' | 'minute' | 'second';
  degrees: number;
  color?: string;
}

const ClockHand = ({ type, degrees, color }: ClockHandProps) => {
  // Set different lengths and thicknesses based on hand type
  let handStyles: React.CSSProperties = {
    position: 'absolute',
    transformOrigin: '50% 100%',
    bottom: '50%',
    left: '50%',
    transform: `rotate(${degrees}deg)`,
    backgroundColor: color || '#000',
    boxShadow: '0 0 5px rgba(0, 0, 0, 0.3)',
    zIndex: 20
  };
  
  if (type === 'hour') {
    handStyles = {
      ...handStyles,
      width: '6px',
      height: '25%',
      borderRadius: '4px',
      marginLeft: '-3px'
    };
  } else if (type === 'minute') {
    handStyles = {
      ...handStyles,
      width: '4px',
      height: '35%',
      borderRadius: '4px',
      marginLeft: '-2px'
    };
  } else {
    handStyles = {
      ...handStyles,
      width: '2px',
      height: '40%',
      borderRadius: '1px',
      marginLeft: '-1px'
    };
  }
  
  // Using inline styles for better control of hand appearance
  return (
    <div
      className={`clock-hand ${type}-hand`}
      style={handStyles}
    ></div>
  );
};

export default ClockHand;
