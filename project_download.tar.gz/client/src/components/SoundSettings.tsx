import React, { useState } from 'react';
import { useClockSettings } from '@/contexts/ClockSettingsContext';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Lock, Play, Info } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

// Sound options interface
interface SoundOption {
  id: string;
  name: string;
  description: string;
  previewUrl: string;
  isPremium: boolean;
}

const SoundSettings = () => {
  const { settings, updateSettings, isLoading } = useClockSettings();
  
  // Local state for the form
  const [selectedAlarmSound, setSelectedAlarmSound] = useState(settings.alarmSound);
  const [selectedTimerSound, setSelectedTimerSound] = useState(settings.timerSound);
  const [soundTheme, setSoundTheme] = useState(settings.soundTheme);
  const [isPlaying, setIsPlaying] = useState<string | null>(null);
  
  // Audio element ref
  const audioRef = React.useRef<HTMLAudioElement | null>(null);
  
  // Sound themes
  const soundThemes = [
    { id: 'basic', name: 'Basic', description: 'Simple notification sounds' },
    { id: 'nba', name: 'NBA Arena', description: 'Authentic NBA arena sounds', isPremium: true },
    { id: 'nature', name: 'Nature', description: 'Calming natural sounds', isPremium: true },
    { id: 'urban', name: 'Urban', description: 'City and street sounds', isPremium: true },
  ];
  
  // Alarm sounds
  const alarmSounds: SoundOption[] = [
    { id: 'digital', name: 'Digital', description: 'Standard digital alarm', previewUrl: '/sounds/digital-alarm.mp3', isPremium: false },
    { id: 'buzzer', name: 'Buzzer', description: 'Basketball game buzzer', previewUrl: '/sounds/buzzer.mp3', isPremium: false },
    { id: 'arena', name: 'Arena', description: 'NBA arena atmosphere', previewUrl: '/sounds/arena.mp3', isPremium: true },
    { id: 'commentator', name: 'Commentator', description: 'Game-winning shot call', previewUrl: '/sounds/commentator.mp3', isPremium: true },
  ];
  
  // Timer sounds
  const timerSounds: SoundOption[] = [
    { id: 'beep', name: 'Beep', description: 'Simple beep sound', previewUrl: '/sounds/beep.mp3', isPremium: false },
    { id: 'whistle', name: 'Whistle', description: 'Referee whistle', previewUrl: '/sounds/whistle.mp3', isPremium: false },
    { id: 'countdown', name: 'Countdown', description: 'Arena countdown', previewUrl: '/sounds/countdown.mp3', isPremium: true },
    { id: 'crowd', name: 'Crowd', description: 'Crowd cheering', previewUrl: '/sounds/crowd.mp3', isPremium: true },
  ];
  
  // Play sound preview
  const playSound = (soundId: string, category: 'alarm' | 'timer') => {
    // For now, we'll just simulate sound playing
    if (isPlaying === soundId) {
      setIsPlaying(null);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    } else {
      setIsPlaying(soundId);
      
      // In a real implementation, we would play the actual sound file:
      // if (audioRef.current) {
      //   const sounds = category === 'alarm' ? alarmSounds : timerSounds;
      //   const sound = sounds.find(s => s.id === soundId);
      //   if (sound) {
      //     audioRef.current.src = sound.previewUrl;
      //     audioRef.current.play();
      //   }
      // }
      
      // For demo, just simulate playing for 2 seconds
      setTimeout(() => {
        if (isPlaying === soundId) {
          setIsPlaying(null);
        }
      }, 2000);
    }
  };
  
  // Save settings
  const saveSettings = async () => {
    await updateSettings({
      soundTheme,
      alarmSound: selectedAlarmSound,
      timerSound: selectedTimerSound,
    });
  };
  
  // Premium dialog content
  const PremiumDialog = ({ soundName }: { soundName: string }) => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="ml-2">
          <Info className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Premium Sound: {soundName}</DialogTitle>
          <DialogDescription>
            This is a premium sound that requires purchase. When you buy premium sounds, a percentage of each sale goes to support the NBA Point Guard Clock creator.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <p className="text-sm text-muted-foreground mb-4">
            Premium sounds offer higher quality audio and more distinctive options for a better experience. Purchase once and use forever!
          </p>
          <Button className="w-full mt-2">
            Purchase Premium Sounds (Coming Soon)
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
  
  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Sound Settings</CardTitle>
        <CardDescription>
          Customize your NBA Point Guard Clock sounds and notifications
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="alarm" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="alarm">Alarm Sounds</TabsTrigger>
            <TabsTrigger value="timer">Timer Sounds</TabsTrigger>
          </TabsList>
          
          <TabsContent value="alarm" className="space-y-4 pt-4">
            <div className="space-y-4">
              <RadioGroup 
                value={selectedAlarmSound}
                onValueChange={setSelectedAlarmSound}
                className="space-y-2"
              >
                {alarmSounds.map((sound) => (
                  <div 
                    key={sound.id} 
                    className="flex items-center justify-between rounded-md border p-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem 
                        value={sound.id}
                        id={`alarm-${sound.id}`}
                        disabled={sound.isPremium && !settings.hasCustomSounds}
                      />
                      <Label 
                        htmlFor={`alarm-${sound.id}`}
                        className={`font-medium ${sound.isPremium && !settings.hasCustomSounds ? 'text-muted-foreground' : ''}`}
                      >
                        {sound.name}
                        {sound.isPremium && (
                          <Badge variant="outline" className="ml-2">
                            <Lock className="h-3 w-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                      </Label>
                    </div>
                    <div className="flex items-center">
                      {sound.isPremium && !settings.hasCustomSounds ? (
                        <PremiumDialog soundName={sound.name} />
                      ) : (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => playSound(sound.id, 'alarm')}
                          aria-label={`Play ${sound.name} sound`}
                        >
                          <Play className={`h-4 w-4 ${isPlaying === sound.id ? 'text-green-500' : ''}`} />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </TabsContent>
          
          <TabsContent value="timer" className="space-y-4 pt-4">
            <div className="space-y-4">
              <RadioGroup 
                value={selectedTimerSound}
                onValueChange={setSelectedTimerSound}
                className="space-y-2"
              >
                {timerSounds.map((sound) => (
                  <div 
                    key={sound.id} 
                    className="flex items-center justify-between rounded-md border p-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem 
                        value={sound.id}
                        id={`timer-${sound.id}`}
                        disabled={sound.isPremium && !settings.hasCustomSounds}
                      />
                      <Label 
                        htmlFor={`timer-${sound.id}`}
                        className={`font-medium ${sound.isPremium && !settings.hasCustomSounds ? 'text-muted-foreground' : ''}`}
                      >
                        {sound.name}
                        {sound.isPremium && (
                          <Badge variant="outline" className="ml-2">
                            <Lock className="h-3 w-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                      </Label>
                    </div>
                    <div className="flex items-center">
                      {sound.isPremium && !settings.hasCustomSounds ? (
                        <PremiumDialog soundName={sound.name} />
                      ) : (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => playSound(sound.id, 'timer')}
                          aria-label={`Play ${sound.name} sound`}
                        >
                          <Play className={`h-4 w-4 ${isPlaying === sound.id ? 'text-green-500' : ''}`} />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="mt-8 pt-4 border-t">
          <h3 className="font-medium text-lg mb-4">Sound Themes</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {soundThemes.map((theme) => (
              <div 
                key={theme.id}
                className={`border rounded-md p-4 cursor-pointer transition-all ${
                  soundTheme === theme.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/30' : ''
                } ${theme.isPremium && !settings.hasCustomSounds ? 'opacity-50' : ''}`}
                onClick={() => {
                  if (!theme.isPremium || settings.hasCustomSounds) {
                    setSoundTheme(theme.id);
                  }
                }}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium">
                      {theme.name}
                      {theme.isPremium && (
                        <Badge variant="outline" className="ml-2">
                          <Lock className="h-3 w-3 mr-1" />
                          Premium
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{theme.description}</p>
                  </div>
                  {theme.isPremium && !settings.hasCustomSounds && (
                    <PremiumDialog soundName={theme.name} />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={() => {
            setSelectedAlarmSound(settings.alarmSound);
            setSelectedTimerSound(settings.timerSound);
            setSoundTheme(settings.soundTheme);
          }}
        >
          Reset
        </Button>
        <Button onClick={saveSettings} disabled={isLoading}>
          {isLoading ? 'Saving...' : 'Save Settings'}
        </Button>
      </CardFooter>
      
      {/* Hidden audio element for sound preview */}
      <audio ref={audioRef} className="hidden" />
    </Card>
  );
};

export default SoundSettings;