import React from 'react';

interface TeamMascotProps {
  team: string;
  size?: number;
  className?: string;
}

const TeamMascot: React.FC<TeamMascotProps> = ({ team, size = 40, className = '' }) => {
  // Normalize team name for file path
  let normalizedTeam = team.toLowerCase();
  
  // For safety, handle any mascots that don't exist
  const availableMascots = [
    "lakers", "warriors", "bucks", "suns", "jazz", 
    "pistons", "nets", "mavericks", "76ers", "thunder", "blazers",
    "celtics", "knicks", "spurs", "bulls", "heat", 
    "kings", "grizzlies", "raptors", "clippers", "rockets", "pelicans",
    "cavaliers", "hornets", "pacers", "wizards", "timberwolves", "magic"
  ];
  
  if (!availableMascots.includes(normalizedTeam)) {
    normalizedTeam = "lakers"; // Default mascot
  }

  // Special case for 76ers to handle the number
  if (normalizedTeam === "76ers") {
    normalizedTeam = "76ers";
  }
  
  return (
    <div 
      className={`mascot-container relative ${className}`}
      style={{ width: size, height: size }}
    >
      <img 
        src={`/images/mascot-${normalizedTeam}.svg`} 
        alt={`${team} Mascot`}
        width={size}
        height={size}
        className="mascot-image"
      />
    </div>
  );
};

export default TeamMascot;