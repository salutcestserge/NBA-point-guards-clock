import React, { createContext, useContext, useEffect, useState } from 'react';

// Temporary default user ID (in a real app, this would come from authentication)
const DEFAULT_USER_ID = 1;

interface Timer {
  id: number;
  userId: number;
  duration: number; // in seconds
  label: string;
  createdAt: string;
}

interface NewTimer {
  userId: number;
  duration: number;
  label: string;
}

interface TimerContextType {
  timers: Timer[];
  isLoading: boolean;
  error: Error | null;
  addTimer: (timer: NewTimer) => Promise<Timer>;
  updateTimer: (id: number, timer: Partial<NewTimer>) => Promise<void>;
  deleteTimer: (id: number) => Promise<void>;
}

const TimerContext = createContext<TimerContextType>({
  timers: [],
  isLoading: false,
  error: null,
  addTimer: async () => ({} as Timer),
  updateTimer: async () => {},
  deleteTimer: async () => {},
});

export const useTimers = () => useContext(TimerContext);

export const TimerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [timers, setTimers] = useState<Timer[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  // Fetch timers on mount
  useEffect(() => {
    const fetchTimers = async () => {
      try {
        setIsLoading(true);
        
        try {
          const response = await fetch(`/api/timers/${DEFAULT_USER_ID}`);
          if (response.ok) {
            const data = await response.json();
            setTimers(data);
          } else {
            // If timers don't exist yet, we'll use an empty array and not show an error
            console.log('No timers found, using empty array');
          }
        } catch (err) {
          // API endpoint might not exist yet, so we'll use a default empty array
          console.log('Using default empty timers array');
        }
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch timers'));
        console.error('Error fetching timers:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTimers();
  }, []);

  const addTimer = async (timer: NewTimer): Promise<Timer> => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/timers', {
        method: 'POST',
        body: JSON.stringify(timer),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data: Timer = await response.json();
        setTimers([...timers, data]);
        return data;
      } else {
        const errorText = await response.text();
        console.error('Failed to add timer:', errorText);
        throw new Error(errorText);
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to add timer'));
      console.error('Error adding timer:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const updateTimer = async (id: number, updateData: Partial<NewTimer>) => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/timers/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setTimers(timers.map(timer => timer.id === id ? data : timer));
      } else {
        console.error('Failed to update timer:', await response.text());
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to update timer'));
      console.error('Error updating timer:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteTimer = async (id: number) => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/timers/${id}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setTimers(timers.filter(timer => timer.id !== id));
      } else {
        console.error('Failed to delete timer:', await response.text());
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to delete timer'));
      console.error('Error deleting timer:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <TimerContext.Provider 
      value={{ timers, isLoading, error, addTimer, updateTimer, deleteTimer }}
    >
      {children}
    </TimerContext.Provider>
  );
};