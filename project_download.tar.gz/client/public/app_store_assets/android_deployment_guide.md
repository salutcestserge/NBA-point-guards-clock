# NBA Point Guard Clock - Android Deployment Guide

This guide will walk you through the complete process of preparing and deploying your NBA Point Guard Clock app to the Google Play Store.

## Prerequisites

Before you begin, make sure you have:

- [ ] Downloaded your complete project including the `keystores` folder
- [ ] Installed [Android Studio](https://developer.android.com/studio)
- [ ] Created a [Google Play Developer account](https://play.google.com/console/signup) ($25 one-time fee)
- [ ] The keystore password from `keystores/keystore_info.md`

## Step 1: Prepare Your Environment

1. Install Node.js and npm if you haven't already
2. Open a terminal in your project directory and run:
   ```bash
   npm install
   ```
3. Install the Android platform for Capacitor:
   ```bash
   npx cap add android
   ```
4. Build your web app:
   ```bash
   npm run build
   ```
5. Copy web assets to Android:
   ```bash
   npx cap sync android
   ```

## Step 2: Open and Configure in Android Studio

1. Open Android Studio
2. Select "Open an existing Android Studio project"
3. Navigate to your project's `android` folder and click "Open"
4. Wait for the project to build and sync
5. Verify your Android SDK is properly installed

## Step 3: Test on an Emulator

1. In Android Studio, click the "Run" button
2. Create a new virtual device if prompted
3. Test all app functionality thoroughly
4. Verify that notifications, alarms, and all features work properly

## Step 4: Build a Signed Release APK

1. In Android Studio, go to Build → Generate Signed Bundle / APK
2. Select "Android App Bundle" (recommended) or "APK"
3. Click "Next"
4. For Key store path, select your keystore: `keystores/android.keystore`
5. Enter your keystore password: `NBAcl0ck!S3cur3`
6. Enter your key alias: `nbapgclock`
7. Enter your key password: `NBAcl0ck!S3cur3`
8. Click "Next"
9. Select "release" build variant
10. Click "Finish"
11. Wait for the build to complete - the file will be generated in:
    - `android/app/release/app-release.aab` (for App Bundle)
    - or `android/app/release/app-release.apk` (for APK)

## Step 5: Prepare Store Listing Materials

Gather the following assets:

1. **App Icon**: High-resolution icon (512x512px PNG)
2. **Feature Graphic**: Main promotional banner (1024x500px JPG/PNG)
3. **Screenshots**:
   - Phone: At least 2 screenshots (16:9 aspect ratio, min 320px wide)
   - Tablet: At least 2 screenshots (if you support tablets)
4. **Short Description**: Concise app description (80 characters max)
5. **Full Description**: Detailed app description (4000 characters max)
6. **App Category**: Choose "Productivity" or "Tools"
7. **Content Rating**: Complete the questionnaire
8. **Privacy Policy URL**: Link to your hosted privacy policy

## Step 6: Create Your Google Play Listing

1. Log in to your [Google Play Console](https://play.google.com/console)
2. Click "Create app"
3. Enter your app name: "NBA Point Guard Clock"
4. Select default language
5. Select "Apps & Games" for app type
6. Choose whether the app is free or paid
7. Check the "Developer Program Policies" checkbox
8. Click "Create app"

## Step 7: Complete the Store Listing

Fill out the following sections in the Play Console:

1. **App details**: Add descriptions, screenshots, feature graphic, etc.
2. **Content rating**: Complete the questionnaire
3. **Target audience**: Define age groups
4. **Store settings**: Category, contact details and privacy policy
5. **Pricing & distribution**: Choose countries and pricing

## Step 8: Upload Your App Bundle or APK

1. In the Play Console, go to "Production" → "Create new release"
2. Click "Continue"
3. Upload your App Bundle (.aab) or APK file
4. Add release notes
5. Save and review release
6. Click "Start rollout to Production"

## Step 9: Publish Your App

1. Review all sections and ensure all requirements are met
2. Resolve any warnings or errors
3. Submit the app for review
4. Wait for Google to review your app (typically 1-3 days)
5. Once approved, your app will be live on the Play Store!

## Troubleshooting Common Issues

- **Build failures**: Check for incompatible plugin versions
- **Signing issues**: Verify keystore path and passwords
- **Release rejected**: Read Google's feedback and address all policy violations
- **App crashes**: Test thoroughly before submission
- **Performance issues**: Optimize web assets and check for memory leaks

## App Updates

When you want to update your app in the future:

1. Make your changes to the app
2. Increase `versionCode` and update `versionName` in `android/app/build.gradle`
3. Rebuild and generate a new signed bundle/APK
4. Create a new release in the Play Console
5. Upload the new bundle/APK
6. Add release notes describing your changes
7. Submit for review

## Important Notes

- **NEVER lose your keystore file or forget the password!** Without it, you cannot update your app.
- Keep your Capacitor and associated plugins updated for security reasons.
- Monitor your Play Console for crash reports and user feedback.
- Consider implementing a phased rollout for major updates (start with 10-20% of users).
- Always test thoroughly on multiple devices before releasing.

## Resources

- [Google Play Console Help](https://support.google.com/googleplay/android-developer)
- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Android Developer Guidelines](https://developer.android.com/guide)