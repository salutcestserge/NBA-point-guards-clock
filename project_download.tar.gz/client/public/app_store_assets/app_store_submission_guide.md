# NBA Point Guard Clock - App Store Submission Guide

This guide provides step-by-step instructions for submitting the NBA Point Guard Clock app to the Google Play Store and Apple App Store.

## Google Play Store Submission

### 1. Prerequisite Setup

- Create a Google Play Developer account ($25 one-time fee) at [play.google.com/apps/publish](https://play.google.com/apps/publish)
- Prepare your organization information
- Complete tax information

### 2. Create a new app listing

1. Log in to the Google Play Console
2. Click "Create app"
3. Fill in the app details:
   - App name: "NBA Point Guard Clock"
   - Default language: English (United States)
   - App or game: Game
   - Free or paid: Free
   - Declarations:
     - App contains ads: No
     - App contains in-app purchases: No
     - Content guidelines: Confirm compliance
   - Click "Create app"

### 3. Set up the store listing

1. Prepare and upload graphic assets:
   - High-resolution icon (512 x 512 px)
   - Feature graphic (1024 x 500 px) found in `android/app/src/main/play/feature-graphic.svg`
   - At least 8 phone screenshots (minimum 3):
     - 16:9 aspect ratio (e.g., 1920 x 1080 px)
     - 9:16 aspect ratio (e.g., 1080 x 1920 px)
   - Optional: Tablet screenshots (7-inch and 10-inch)

2. Fill in text fields:
   - Short description (80 characters max): 
     - "Interactive NBA-themed clock featuring legendary point guards."
   - Full description (4000 characters max):
     - Copy from `app_description.md`
   - Add relevant tags

### 4. Set up the app content

1. Complete app access:
   - Select "All functionality is available without special access"

2. Complete content rating questionnaire:
   - Category: Utility
   - Answer all questions honestly (app should receive E for Everyone)
   - Submit for rating

3. Target audience:
   - Select "All ages"
   - Confirm app appeals to children
   - Confirm compliance with family policies

4. Select category:
   - Primary: Sports
   - Secondary: Utilities

### 5. Set up pricing and distribution

1. Select free app
2. Select countries for distribution (typically all countries)
3. Confirm app meets Play Store guidelines

### 6. Create release

1. Go to "Production" track
2. Click "Create new release"
3. Upload the signed APK/AAB:
   - Generate through Android Studio
   - Sign with your keystore (store the keystore securely!)
4. Add release notes (initial version)
5. Review and start rollout

### 7. Finalize and submit

1. Verify all sections are complete (checkmarks should appear)
2. Submit for review
3. Wait for approval (typically 1-3 days)

## Apple App Store Submission

### 1. Prerequisite Setup

- Enroll in the Apple Developer Program ($99/year) at [developer.apple.com/programs](https://developer.apple.com/programs/)
- Set up your team and organization information
- Generate and install required certificates and profiles

### 2. Prepare App Store Connect

1. Log in to [App Store Connect](https://appstoreconnect.apple.com/)
2. Click the "+" button to create a new app
3. Fill in required information:
   - Platform: iOS
   - App Name: "NBA Point Guard Clock"
   - Primary language: English (U.S.)
   - Bundle ID: Select from your registered IDs
   - SKU: Create a unique identifier
   - User Access: Full Access

### 3. Prepare App Information

1. Fill out App Information:
   - Privacy Policy URL: Link to hosted privacy policy at `https://yourdomain.com/privacy-policy.html`
   - Category: 
     - Primary: Sports
     - Secondary: Utilities
   - Age Rating: Complete questionnaire (should be 4+)

2. Pricing and Availability:
   - Set price (Free)
   - Select availability date
   - Select countries

### 4. Prepare App Version Information

1. Screenshots: Upload for all required device sizes
   - iPhone: 6.5", 5.5", and 4.7" displays
   - iPad: 12.9" and 9.7" displays

2. Fill in text fields:
   - Promotional text (170 characters)
   - Description (from `app_description.md`)
   - Keywords (comma-separated, 100 characters max)
   - Support URL
   - Marketing URL (optional)

### 5. Build Submission

1. Use Xcode to build and upload:
   ```
   npx cap add ios
   npx cap sync ios
   npx cap open ios
   ```

2. In Xcode:
   - Set proper version and build numbers
   - Select Generic iOS Device as target
   - Menu -> Product -> Archive
   - In the Organizer window, click "Distribute App"
   - Select "App Store Connect" and follow prompts

3. Return to App Store Connect:
   - Wait for build to process (can take up to an hour)
   - Select the build in the "Build" section

### 6. Finalize Submission

1. Complete "App Review Information":
   - Contact details
   - Notes for reviewers
   - Login information (if needed)

2. Complete "Version Release":
   - Automatic release after approval
   - Manual release

3. Submit for Review
   - Click "Submit for Review"
   - Confirm all required export compliance questions
   - Wait for review (typically 1-3 days)

## Tips for Successful Submission

1. **Test thoroughly** before submission to avoid rejection:
   - Test on multiple devices
   - Check for crashes and UI issues
   - Verify all features work as expected

2. **Be ready to respond** to review team questions:
   - Keep email notifications active
   - Respond promptly

3. **Prepare for rejection**:
   - Common reasons: crashes, metadata issues, privacy concerns
   - Fix issues and resubmit promptly

4. **Maintain release schedule**:
   - Plan updates in advance
   - Maintain version numbers consistently
   - Keep release notes clear and helpful

---

This guide covers the basics of app submission. Requirements may change over time, so always check the latest guidelines from Google and Apple before submission.