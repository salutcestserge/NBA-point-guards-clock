# App Store Screenshot Specifications

## Apple App Store (iOS) Screenshot Requirements

### iPhone
- iPhone 6.5" Display (1242 x 2688 pixels)
- iPhone 5.5" Display (1242 x 2208 pixels)
- iPhone 12 Pro Max (1284 x 2778 pixels)

### iPad
- 12.9" iPad Pro (2732 x 2048 pixels)
- 11" iPad Pro (2388 x 1668 pixels)

### Apple Watch
- Apple Watch Series 7 (396 x 484 pixels)

## Google Play Store (Android) Screenshot Requirements

### Phone
- Minimum dimension: 320 pixels
- Maximum dimension: 3840 pixels
- Recommended formats:
  - 16:9 aspect ratio (landscape)
  - 9:16 aspect ratio (portrait)
  - Common sizes: 1920 x 1080 pixels, 1080 x 1920 pixels

### Tablet
- 7-inch tablet (1024 x 600 pixels)
- 10-inch tablet (1280 x 800 pixels)

### TV
- TV screenshots (1920 x 1080 pixels)

### Wear
- Square (512 x 512 pixels)
- Round (512 x 512 pixels)

## Screenshot Ideas for NBA Point Guard Clock App

1. Main Clock View - Show the clock with the dynamic team colors and point guard markers
2. Dark Mode View - Display the same clock in dark mode
3. Alarm Feature - Show the alarm list and setting screen
4. Timer Feature - Showcase the timer functionality
5. World Clock - Display the world clock feature with multiple time zones
6. Settings Screen - Show the customization options

## Tips for Taking Screenshots
- Use device frames to make screenshots look more professional
- Keep the interface language consistent in all screenshots
- Make sure the displayed time is appropriate (avoid times like 4:20)
- Use team colors that are visually appealing
- Consider using multiple devices in one screenshot for lifestyle images
- Avoid using copyrighted NBA logos prominently
- Show both light and dark mode options

## Recommended Screenshot Tools
- iOS Simulator with Command+S to capture screenshots
- Android Studio Emulator screenshots
- Browser dev tools with device emulation
- Cleanup screenshots with image editing software to ensure proper dimensions