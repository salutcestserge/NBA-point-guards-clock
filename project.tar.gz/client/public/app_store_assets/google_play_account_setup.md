# Google Play Developer Account Setup

This guide will walk you through setting up your Google Play Developer account, which is required to publish your app on the Google Play Store.

## Prerequisites

- A Google account (Gmail)
- A credit/debit card for the one-time registration fee ($25 USD)
- Business details if publishing as an organization

## Step 1: Sign Up for a Developer Account

1. Visit the [Google Play Console](https://play.google.com/apps/publish/)
2. Sign in with your Google account
3. Select "Create account" and choose account type:
   - Individual
   - Organization (requires additional verification)
4. Complete your account details:
   - Developer name (will be visible to users)
   - Contact details (email, phone)
   - Address information
5. Agree to the Developer Distribution Agreement
6. Pay the $25 USD registration fee (one-time, not annual)
7. Complete account verification (check your email)

## Step 2: Complete Your Account Details

After registration is approved (usually within 48 hours), log in to the Play Console and:

1. **Set up your payments profile**:
   - Go to "Payments" section
   - Set up merchant account if you plan to sell apps or in-app purchases
   - Add payment method for receiving revenue

2. **Complete your store listing**:
   - Add a developer website URL
   - Add support email address
   - Upload a developer icon (512x512 px)

3. **Tax information**:
   - Complete tax forms (especially important for US tax withholding)
   - Submit W-8 or W-9 form as appropriate

## Step 3: Understanding Google Play Policies

Familiarize yourself with these important policies:

1. [Developer Program Policies](https://play.google.com/about/developer-content-policy/)
2. [Developer Distribution Agreement](https://play.google.com/about/developer-distribution-agreement.html)
3. [Enforcement Process](https://support.google.com/googleplay/android-developer/answer/9899234)

Common policy areas to review:
- Restricted content
- Intellectual property rights
- Privacy, security, and deception
- Monetization and advertising
- Store listing and promotion

## Step 4: Prepare for App Submission

Before submitting your app, ensure you have:

1. **App bundle or APK**:
   - Signed with your production keystore
   - Optimized for size and performance

2. **Store listing assets**:
   - Feature graphic (1024 x 500 px)
   - App icon (512 x 512 px)
   - Screenshots for various devices
   - Promotional video (optional)

3. **Content details**:
   - App description (short and full)
   - App category
   - Content rating information
   - Contact details

4. **Release management**:
   - Choose between production, open testing, closed testing, or internal testing
   - Set up a staged rollout strategy if desired

## Step 5: App Review Process

After submission:

1. Google Play will review your app (typically takes 1-3 days)
2. You'll receive notification of approval or rejection
3. If rejected, review the reasons and make necessary changes
4. Resubmit after fixing any issues

## Tips for a Successful Submission

1. **Thoroughly test your app** on multiple devices
2. **Follow all Play Store guidelines** to avoid rejection
3. **Provide clear descriptions** and high-quality screenshots
4. **Respond promptly** to any requests from the review team
5. **Keep your Play Console account secure** with 2-factor authentication

## Next Steps

After your developer account is set up, you'll be ready to:
1. Create your first app in the Play Console
2. Upload your App Bundle or APK
3. Complete your store listing
4. Set up your release

Reminder: Keep your keystore file and password safe! You will need it for all future updates to your app.