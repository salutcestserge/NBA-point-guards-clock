# Privacy Policy for NBA Point Guard Clock

**Last Updated: April 23, 2025**

## Introduction

Welcome to NBA Point Guard Clock. We respect your privacy and are committed to protecting your personal data. This privacy policy explains how we collect, use, and safeguard your information when you use our mobile application and associated services.

## Who We Are

NBA Point Guard Clock is a mobile and web application that provides a basketball-themed clock and time management tools.

**Contact Information:**  
Email: [your-email@example.com]  
Address: [Your physical address]

## What Information We Collect

### Information You Provide

We may collect and process the following information that you provide:

- **User Preferences**: Your clock settings, themes, and customization options
- **Alarm and Timer Settings**: Time settings, alarm labels, and scheduled alarms
- **Device Time Zone Information**: To accurately display time and manage alarms

### Information Collected Automatically

When you use our application, we may automatically collect:

- **Device Information**: Device type, operating system version, unique device identifiers
- **Usage Data**: How you interact with the app, features used, and time spent using the app
- **Diagnostic Data**: App performance data and crash reports

## How We Use Your Information

We use your information for the following purposes:

- To provide and maintain our service, including managing your alarms and timers
- To save your preferences and settings
- To improve and optimize our application
- To detect, prevent, and address technical issues
- To provide customer support

## Data Storage and Security

Your preferences and settings are primarily stored locally on your device. Limited data may be backed up to our servers for account synchronization if you create an account.

We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.

## Your Rights

Depending on your location, you may have the following rights:

- Access to your personal data
- Correction of inaccurate data
- Deletion of your data
- Restriction of processing
- Data portability

To exercise any of these rights, please contact us using the information provided above.

## Children's Privacy

Our application is not directed at children under the age of 13. We do not knowingly collect personal information from children under 13. If you believe we have collected information from a child under 13, please contact us immediately.

## Third-Party Services

Our application may use the following third-party services:

- **Analytics Services**: To help us understand how users interact with our app
- **Crash Reporting Tools**: To identify and fix application errors

These services may collect information sent by your device. Please review their privacy policies for more information about their practices.

## Changes to This Privacy Policy

We may update this privacy policy from time to time. We will notify you of any changes by posting the new privacy policy on this page and updating the "Last Updated" date.

## California Privacy Rights

California residents may have additional rights regarding their personal information under the California Consumer Privacy Act (CCPA).

## International Data Transfers

Your information may be transferred to and processed in countries other than your country of residence. These countries may have different data protection laws.

## Consent

By using our application, you consent to our privacy policy and agree to its terms.

## Contact Us

If you have any questions about this privacy policy or our practices, please contact us at [your-email@example.com].