# Screenshot Guide for App Store Submission

This guide will help you capture high-quality screenshots of your NBA Point Guard Clock app for submission to the Google Play Store.

## Required Screenshot Types

Google Play Store requires screenshots in the following formats:

1. **Phone Screenshots** (minimum 2, maximum 8)
   - 16:9 aspect ratio (landscape) or 9:16 (portrait)
   - Minimum resolution: 1080 x 1920 pixels (portrait)
   - Recommended: Capture 4-5 screenshots showing different features

2. **7-inch Tablet Screenshots** (optional but recommended)
   - 16:9 aspect ratio (landscape preferred for tablets)
   - Minimum resolution: 1080 x 1920 pixels

3. **10-inch Tablet Screenshots** (optional but recommended)
   - 16:9 aspect ratio (landscape preferred for tablets)
   - Minimum resolution: 1920 x 1200 pixels

## Screenshot Content Recommendations

For the best presentation in the store, include screenshots that show:

1. **Main Clock Screen**
   - Show the clock with hour, minute, and second hands
   - Make sure several NBA point guards are clearly visible
   - Capture with an interesting time (not just 12:00)

2. **Point Guard Details**
   - Show the stats/details popup when tapping on a player
   - Choose a recognizable player like Magic Johnson or Stephen Curry

3. **Alarm/Timer Features**
   - Show the alarm list with a few alarms set
   - Show the timer interface with a timer running

4. **World Clock/Stopwatch**
   - Include a screenshot of the world clock with multiple time zones
   - Include the stopwatch in action

5. **Settings/Customization**
   - Show the settings screen with customization options
   - If possible, show before/after of a theme change

## Screenshot Enhancement Tips

To make your screenshots more appealing:

1. **Add Text Overlays**
   - Add short captions (2-5 words) describing the feature shown
   - Use consistent font and placement across all screenshots
   - Example texts:
     - "Real-time NBA Clock"
     - "Player Stats & History"
     - "Custom Alarms & Timers"
     - "Multiple Time Zones"

2. **Use Device Frames**
   - Consider adding device frames around your screenshots
   - Tools like [Device Art Generator](https://developer.android.com/distribute/marketing-tools/device-art-generator) can help
   - Keep framing consistent across all screenshots

3. **Maintain Visual Consistency**
   - Use the same device and settings for all screenshots
   - Ensure clock theme and colors are consistent (unless showing theme changes)
   - Capture all screenshots in the same ambient lighting condition

## Screenshot Capture Methods

### On Physical Devices
1. Press Power + Volume Down buttons simultaneously
2. Screenshots are saved to the Photos/Gallery app
3. Transfer to your computer via USB or cloud storage

### On Emulators
1. In Android Studio's emulator, use the camera icon in the side toolbar
2. Screenshots are saved to your computer directly

### Using Android Debug Bridge (ADB)
```
adb shell screencap -p /sdcard/screenshot.png
adb pull /sdcard/screenshot.png
```

## Post-Processing

After capturing raw screenshots:

1. **Resize** if necessary to meet minimum requirements
2. **Add text overlays** using image editing software (Photoshop, GIMP, Canva)
3. **Add device frames** if desired
4. **Optimize file size** without losing quality
5. **Name files** consistently (e.g., screenshot_1_main.png, screenshot_2_stats.png)

## Recommended Screenshot Scenes

1. **Screenshot 1: Main Clock**
   - Full clock face with all 12 point guards visible
   - Time showing clearly on analog display
   - Caption: "NBA Legends Clock"

2. **Screenshot 2: Player Details**
   - Player stats popup showing career achievements
   - Background showing clock face
   - Caption: "Legendary Player Stats"

3. **Screenshot 3: Alarm Feature**
   - Alarm list with several alarms
   - Show different days and repeat settings
   - Caption: "Custom Basketball Alarms"

4. **Screenshot 4: Timer Feature**
   - Timer running with basketball-themed UI
   - Caption: "NBA-Themed Timers"

5. **Screenshot 5: Settings**
   - Settings screen showing personalization options
   - Caption: "Customize Your Experience"

## Final Checklist Before Submission

- [ ] All screenshots meet minimum resolution requirements
- [ ] No sensitive/personal information is visible
- [ ] Text is readable and not cut off
- [ ] UI elements are not obscured by overlays
- [ ] Files are in PNG or JPEG format under 8MB each
- [ ] Consistent style across all screenshots
- [ ] Screenshots accurately represent the app functionality

Store your final screenshots in a dedicated folder for easy access during the app submission process.