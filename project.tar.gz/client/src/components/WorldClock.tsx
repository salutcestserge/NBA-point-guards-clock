import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Plus, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Predefined popular time zones
const popularTimeZones = [
  { id: "UTC", name: "UTC (Coordinated Universal Time)", offset: 0 },
  { id: "America/New_York", name: "New York (EST/EDT)", offset: -5 },
  { id: "America/Los_Angeles", name: "Los Angeles (PST/PDT)", offset: -8 },
  { id: "Europe/London", name: "London (GMT/BST)", offset: 0 },
  { id: "Europe/Paris", name: "Paris (CET/CEST)", offset: 1 },
  { id: "Asia/Tokyo", name: "Tokyo (JST)", offset: 9 },
  { id: "Asia/Shanghai", name: "Shanghai (CST)", offset: 8 },
  { id: "Australia/Sydney", name: "Sydney (AEST/AEDT)", offset: 10 },
  { id: "Pacific/Auckland", name: "Auckland (NZST/NZDT)", offset: 12 }
];

// Interface for a clock entry
interface ClockEntry {
  id: string;
  name: string;
  timeZone: string;
  offset: number;
}

export default function WorldClock() {
  const [clocks, setClocks] = useState<ClockEntry[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [newClockName, setNewClockName] = useState("");
  const [newTimeZone, setNewTimeZone] = useState("");
  const { toast } = useToast();
  
  // Update all clocks every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Initialize with a default clock if empty
  useEffect(() => {
    if (clocks.length === 0) {
      // Add the local time zone
      const localTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const localOffset = new Date().getTimezoneOffset() / -60; // Convert to hours and invert
      
      setClocks([
        {
          id: "local",
          name: "Local Time",
          timeZone: localTimeZone,
          offset: localOffset
        }
      ]);
    }
  }, [clocks.length]);
  
  const handleAddClock = () => {
    if (!newTimeZone) {
      toast({
        title: "Error",
        description: "Please select a time zone",
        variant: "destructive"
      });
      return;
    }
    
    const selectedTimeZone = popularTimeZones.find(tz => tz.id === newTimeZone);
    
    if (!selectedTimeZone) {
      toast({
        title: "Error",
        description: "Invalid time zone selected",
        variant: "destructive"
      });
      return;
    }
    
    const clockName = newClockName.trim() || selectedTimeZone.name.split(" ")[0];
    
    // Check if this time zone already exists
    if (clocks.some(clock => clock.timeZone === newTimeZone)) {
      toast({
        title: "Error",
        description: "This time zone is already added",
        variant: "destructive"
      });
      return;
    }
    
    // Add the new clock
    setClocks([
      ...clocks,
      {
        id: `clock-${Date.now()}`,
        name: clockName,
        timeZone: newTimeZone,
        offset: selectedTimeZone.offset
      }
    ]);
    
    // Reset form
    setNewClockName("");
    setNewTimeZone("");
    setShowAddForm(false);
    
    toast({
      title: "Clock added",
      description: `${clockName} has been added to your world clocks`
    });
  };
  
  const handleRemoveClock = (id: string) => {
    setClocks(clocks.filter(clock => clock.id !== id));
    
    toast({
      title: "Clock removed",
      description: "The clock has been removed from your list"
    });
  };
  
  // Format the time for a specific time zone
  const formatTimeForZone = (date: Date, timeZone: string) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone
    }).format(date);
  };
  
  // Format the date for a specific time zone
  const formatDateForZone = (date: Date, timeZone: string) => {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      timeZone
    }).format(date);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-oswald font-semibold">WORLD CLOCK</h2>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          {showAddForm ? "Cancel" : (
            <>
              <Plus className="h-4 w-4 mr-1" />
              Add Clock
            </>
          )}
        </Button>
      </div>
      
      {showAddForm && (
        <Card className="border border-gray-200 mb-6">
          <CardContent className="p-4">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="clockName">Clock Name (optional)</Label>
                  <Input
                    id="clockName"
                    placeholder="e.g., Home, Office, Tokyo"
                    value={newClockName}
                    onChange={(e) => setNewClockName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timeZone">Time Zone</Label>
                  <Select 
                    value={newTimeZone} 
                    onValueChange={setNewTimeZone}
                  >
                    <SelectTrigger id="timeZone">
                      <SelectValue placeholder="Select time zone" />
                    </SelectTrigger>
                    <SelectContent>
                      {popularTimeZones.map((tz) => (
                        <SelectItem key={tz.id} value={tz.id}>
                          {tz.name} (UTC{tz.offset >= 0 ? '+' : ''}{tz.offset})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button onClick={handleAddClock}>
                  <Globe className="h-4 w-4 mr-1" />
                  Add Clock
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* World clocks grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {clocks.map((clock) => (
          <Card key={clock.id} className="border border-gray-200 bg-white">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-medium">{clock.name}</h3>
                  <p className="text-sm text-gray-500">
                    {popularTimeZones.find(tz => tz.id === clock.timeZone)?.name || clock.timeZone}
                  </p>
                </div>
                
                {clock.id !== "local" && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveClock(clock.id)}
                    className="text-gray-500 hover:text-red-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
              
              <div className="mt-4">
                <div className="text-3xl font-mono font-semibold tracking-wider">
                  {formatTimeForZone(currentTime, clock.timeZone)}
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {formatDateForZone(currentTime, clock.timeZone)}
                </div>
              </div>
              
              <div className="mt-2 text-xs text-gray-500">
                UTC{clock.offset >= 0 ? '+' : ''}{clock.offset}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}