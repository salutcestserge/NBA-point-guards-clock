import React from "react";
import {
  FaApple,
  FaAndroid,
  FaAppStoreIos,
  FaGooglePlay,
  FaDesktop,
  FaClock,
} from "react-icons/fa";

export default function DownloadApp() {
  return (
    <div className="p-6 rounded-lg bg-white shadow-xl">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">
        Download NBA Point Guard Clock
      </h2>

      <p className="mb-6 text-gray-600">
        Get the NBA Point Guard Clock app on your preferred device. Available
        for iOS, Android, macOS, and Apple Watch.
      </p>

      <div className="space-y-6">
        {/* Mobile Platforms */}
        <div>
          <h3 className="text-lg font-semibold mb-3 text-gray-700">
            Mobile Devices
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* iOS */}
            <button
              className="p-4 h-auto flex items-center justify-between border-2 hover:border-blue-500 transition-colors rounded-md"
              onClick={() =>
                window.open(
                  "https://apps.apple.com/app/nba-pg-clock/id123456789",
                  "_blank",
                )
              }
            >
              <div className="flex items-center">
                <FaApple className="mr-3 text-2xl text-black" />
                <div className="text-left">
                  <p className="text-sm text-gray-500">Download on the</p>
                  <p className="font-semibold text-black">App Store</p>
                </div>
              </div>
              <FaAppStoreIos className="text-xl text-gray-600" />
            </button>

            {/* Android */}
            <button
              className="p-4 h-auto flex items-center justify-between border-2 hover:border-green-500 transition-colors rounded-md"
              onClick={() =>
                window.open(
                  "https://play.google.com/store/apps/details?id=com.nbapgclock",
                  "_blank",
                )
              }
            >
              <div className="flex items-center">
                <FaAndroid className="mr-3 text-2xl text-black" />
                <div className="text-left">
                  <p className="text-sm text-gray-500">Get it on</p>
                  <p className="font-semibold text-black">Google Play</p>
                </div>
              </div>
              <FaGooglePlay className="text-xl text-gray-600" />
            </button>
          </div>
        </div>

        <hr className="border-t border-gray-200" />

        {/* Desktop & Watch */}
        <div>
          <h3 className="text-lg font-semibold mb-3 text-gray-700">
            Desktop & Wearables
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* macOS */}
            <button
              className="p-4 h-auto flex items-center justify-between border-2 hover:border-blue-500 transition-colors rounded-md"
              onClick={() =>
                window.open(
                  "https://apps.apple.com/app/nba-pg-clock-desktop/id987654321",
                  "_blank",
                )
              }
            >
              <div className="flex items-center">
                <FaDesktop className="mr-3 text-2xl text-black" />
                <div className="text-left">
                  <p className="text-sm text-gray-500">Download for</p>
                  <p className="font-semibold text-black">macOS</p>
                </div>
              </div>
              <FaApple className="text-xl text-gray-600" />
            </button>

            {/* Apple Watch */}
            <button
              className="p-4 h-auto flex items-center justify-between border-2 hover:border-blue-500 transition-colors rounded-md"
              onClick={() =>
                window.open(
                  "https://apps.apple.com/app/nba-pg-clock-watch/id543216789",
                  "_blank",
                )
              }
            >
              <div className="flex items-center">
                <FaClock className="mr-3 text-2xl text-black" />
                <div className="text-left">
                  <p className="text-sm text-gray-500">Download for</p>
                  <p className="font-semibold text-black">Apple Watch</p>
                </div>
              </div>
              <FaApple className="text-xl text-gray-600" />
            </button>
          </div>
        </div>

        <hr className="border-t border-gray-200" />

        {/* Web App */}
        <div>
          <h3 className="text-lg font-semibold mb-3 text-gray-700">Web App</h3>

          <div className="text-center">
            <p className="mb-3 text-gray-600">
              Use the NBA Point Guard Clock right in your browser. Add it to
              your home screen for easy access.
            </p>

            <button
              className="px-8 py-2 bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white rounded-md"
              onClick={() => {
                // Logic to show "Add to Home Screen" instructions
                alert(
                  "To install this app on your device:\n\n• On iOS: Tap the share icon and then 'Add to Home Screen'\n• On Android: Tap the menu icon and then 'Add to Home Screen'\n• On Desktop: Click the install icon in the address bar",
                );
              }}
            >
              Install Web App
            </button>
          </div>
        </div>
      </div>

      <div className="mt-8 pt-4 border-t border-gray-200">
        <p className="text-xs text-gray-500">
          By downloading, you agree to our{" "}
          <a
            href="/terms-of-service.html"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-blue-500"
          >
            Terms of Service
          </a>{" "}
          and{" "}
          <a
            href="/privacy-policy.html"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-blue-500"
          >
            Privacy Policy
          </a>
          .
        </p>
      </div>
    </div>
  );
}
