import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPointGuardSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all point guards
  app.get("/api/pointguards", async (req, res) => {
    try {
      const pointGuards = await storage.getAllPointGuards();
      res.json(pointGuards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch point guards" });
    }
  });

  // Get point guard by ID
  app.get("/api/pointguards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const pointGuard = await storage.getPointGuard(id);
      if (!pointGuard) {
        return res.status(404).json({ message: "Point guard not found" });
      }

      res.json(pointGuard);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch point guard" });
    }
  });

  // Add default point guard data if none exists
  app.post("/api/pointguards/initialize", async (req, res) => {
    try {
      const existingGuards = await storage.getAllPointGuards();
      
      if (existingGuards.length === 0) {
        // Add the 12 greatest point guards of all time
        const defaultPointGuards = [
          {
            name: "Magic Johnson",
            team: "Lakers",
            imageUrl: "/images/cartoon-pg-1.svg",
            jerseyNumber: 32,
            position: 1, // Position on clock
            ppg: "19.5",
            apg: "11.2",
            achievements: "5x NBA Champion, 3x MVP, 12x All-Star"
          },
          {
            name: "Stephen Curry",
            team: "Warriors",
            imageUrl: "/images/cartoon-pg-2.svg",
            jerseyNumber: 30,
            position: 2,
            ppg: "24.6",
            apg: "6.5",
            achievements: "4x NBA Champion, 2x MVP, 9x All-Star"
          },
          {
            name: "Oscar Robertson",
            team: "Bucks",
            imageUrl: "/images/cartoon-pg-3.svg",
            jerseyNumber: 1,
            position: 3,
            ppg: "25.7",
            apg: "9.5",
            achievements: "1x NBA Champion, 1x MVP, 12x All-Star"
          },
          {
            name: "Chris Paul",
            team: "Suns",
            imageUrl: "/images/cartoon-pg-4.svg",
            jerseyNumber: 3,
            position: 4,
            ppg: "17.9",
            apg: "9.5",
            achievements: "12x All-Star, 11x All-NBA, 9x All-Defensive"
          },
          {
            name: "John Stockton",
            team: "Jazz",
            imageUrl: "/images/cartoon-pg-5.svg",
            jerseyNumber: 12,
            position: 5,
            ppg: "13.1",
            apg: "10.5",
            achievements: "10x All-Star, All-time assists leader"
          },
          {
            name: "Isiah Thomas",
            team: "Pistons",
            imageUrl: "/images/cartoon-pg-6.svg",
            jerseyNumber: 11,
            position: 6,
            ppg: "19.2",
            apg: "9.3",
            achievements: "2x NBA Champion, 12x All-Star, Finals MVP"
          },
          {
            name: "Jason Kidd",
            team: "Nets",
            imageUrl: "/images/cartoon-pg-7.svg",
            jerseyNumber: 5,
            position: 7,
            ppg: "12.6",
            apg: "8.7",
            achievements: "1x NBA Champion, 10x All-Star, 5x All-NBA"
          },
          {
            name: "Steve Nash",
            team: "Suns",
            imageUrl: "/images/cartoon-pg-8.svg",
            jerseyNumber: 13,
            position: 8,
            ppg: "14.3",
            apg: "8.5",
            achievements: "2x MVP, 8x All-Star, 7x All-NBA"
          },
          {
            name: "Luka Doncic",
            team: "Mavericks",
            imageUrl: "/images/cartoon-pg-9.svg",
            jerseyNumber: 77,
            position: 9,
            ppg: "28.7",
            apg: "8.4",
            achievements: "5x All-Star, 4x All-NBA First Team, ROY"
          },
          {
            name: "Allen Iverson",
            team: "76ers",
            imageUrl: "/images/cartoon-pg-10.svg",
            jerseyNumber: 3,
            position: 10,
            ppg: "26.7",
            apg: "6.2",
            achievements: "1x MVP, 11x All-Star, 7x All-NBA"
          },
          {
            name: "Russell Westbrook",
            team: "Thunder",
            imageUrl: "/images/cartoon-pg-11.svg",
            jerseyNumber: 0,
            position: 11,
            ppg: "22.0",
            apg: "8.3",
            achievements: "1x MVP, 9x All-Star, Triple-double record"
          },
          {
            name: "Damian Lillard",
            team: "Blazers",
            imageUrl: "/images/cartoon-pg-12.svg",
            jerseyNumber: 0,
            position: 12,
            ppg: "25.2",
            apg: "6.7",
            achievements: "7x All-Star, 6x All-NBA, Rookie of the Year"
          }
        ];

        for (const guard of defaultPointGuards) {
          try {
            const parsedGuard = insertPointGuardSchema.parse(guard);
            await storage.createPointGuard(parsedGuard);
          } catch (parseError) {
            console.error("Error parsing point guard data:", parseError);
          }
        }

        return res.json({ message: "Point guard data initialized successfully" });
      }

      res.json({ message: "Point guard data already exists" });
    } catch (error) {
      res.status(500).json({ message: "Failed to initialize point guard data" });
    }
  });

  // Create initial data when the server starts
  setTimeout(async () => {
    try {
      const response = await fetch("http://localhost:5000/api/pointguards/initialize", {
        method: "POST",
      });
      const data = await response.json();
      console.log("Initialization result:", data);
    } catch (error) {
      console.error("Failed to initialize point guard data:", error);
    }
  }, 1000);

  // User settings routes
  app.get("/api/settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      const settings = await storage.getUserSettings(userId);
      
      if (!settings) {
        // Create default settings if none exist
        const defaultSettings = {
          userId,
          theme: "default",
          clockColor: "#343A40",
          hourHandColor: "#1E40AF",
          minuteHandColor: "#343A40",
          secondHandColor: "#DC2626",
          use24HourFormat: false,
          showSeconds: true,
          soundTheme: "basic",
          alarmSound: "digital",
          timerSound: "beep",
          hasCustomSounds: false,
          darkMode: false
        };
        const newSettings = await storage.createUserSettings(defaultSettings);
        res.json(newSettings);
      } else {
        res.json(settings);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });
  
  app.put("/api/settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      const updateData = req.body;
      
      let settings = await storage.getUserSettings(userId);
      
      if (!settings) {
        // Create new settings with request data
        const newSettings = {
          userId,
          ...updateData
        };
        settings = await storage.createUserSettings(newSettings);
      } else {
        // Update existing settings
        settings = await storage.updateUserSettings(userId, updateData);
      }
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user settings" });
    }
  });
  
  // Alarm routes
  app.get("/api/alarms/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      const alarms = await storage.getAlarms(userId);
      res.json(alarms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch alarms" });
    }
  });
  
  app.post("/api/alarms", async (req, res) => {
    try {
      const alarm = req.body;
      const newAlarm = await storage.createAlarm(alarm);
      res.status(201).json(newAlarm);
    } catch (error) {
      res.status(500).json({ message: "Failed to create alarm" });
    }
  });
  
  app.put("/api/alarms/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid alarm ID format" });
      }
      
      const updateData = req.body;
      const updatedAlarm = await storage.updateAlarm(id, updateData);
      res.json(updatedAlarm);
    } catch (error) {
      res.status(500).json({ message: "Failed to update alarm" });
    }
  });
  
  app.delete("/api/alarms/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid alarm ID format" });
      }
      
      const success = await storage.deleteAlarm(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "Alarm not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete alarm" });
    }
  });
  
  // Timer routes
  app.get("/api/timers/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      const timers = await storage.getTimers(userId);
      res.json(timers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch timers" });
    }
  });
  
  app.post("/api/timers", async (req, res) => {
    try {
      const timer = req.body;
      const newTimer = await storage.createTimer(timer);
      res.status(201).json(newTimer);
    } catch (error) {
      res.status(500).json({ message: "Failed to create timer" });
    }
  });
  
  app.put("/api/timers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid timer ID format" });
      }
      
      const updateData = req.body;
      const updatedTimer = await storage.updateTimer(id, updateData);
      res.json(updatedTimer);
    } catch (error) {
      res.status(500).json({ message: "Failed to update timer" });
    }
  });
  
  app.delete("/api/timers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid timer ID format" });
      }
      
      const success = await storage.deleteTimer(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "Timer not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete timer" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
