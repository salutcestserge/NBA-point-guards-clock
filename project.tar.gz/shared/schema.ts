import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const pointGuards = pgTable("point_guards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  team: text("team").notNull(),
  imageUrl: text("image_url").notNull(),
  jerseyNumber: integer("jersey_number").notNull(),
  position: integer("position").notNull(), // Position on the clock (1-12)
  ppg: text("ppg").notNull(), // Points per game
  apg: text("apg").notNull(), // Assists per game
  achievements: text("achievements").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPointGuardSchema = createInsertSchema(pointGuards).omit({
  id: true,
});

// Define alarm schema
export const alarms = pgTable("alarms", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  time: text("time").notNull(), // Format: "HH:MM"
  label: text("label").notNull(),
  days: text("days").notNull(), // Format: "0,1,2,3,4,5,6" representing days of week
  enabled: boolean("enabled").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Define user settings schema
export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).unique(),
  theme: text("theme").default("default"),
  clockColor: text("clock_color").default("#343A40"),
  hourHandColor: text("hour_hand_color").default("#1E40AF"),
  minuteHandColor: text("minute_hand_color").default("#343A40"),
  secondHandColor: text("second_hand_color").default("#DC2626"),
  use24HourFormat: boolean("use_24_hour_format").default(false),
  showSeconds: boolean("show_seconds").default(true),
  soundTheme: text("sound_theme").default("basic"),
  alarmSound: text("alarm_sound").default("digital"),
  timerSound: text("timer_sound").default("beep"),
  hasCustomSounds: boolean("has_custom_sounds").default(false),
  darkMode: boolean("dark_mode").default(false),
});

// Define timers schema
export const timers = pgTable("timers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  duration: integer("duration").notNull(), // in seconds
  label: text("label").default("Timer"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertAlarmSchema = createInsertSchema(alarms).omit({
  id: true,
  createdAt: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
});

export const insertTimerSchema = createInsertSchema(timers).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type PointGuard = typeof pointGuards.$inferSelect;
export type InsertPointGuard = z.infer<typeof insertPointGuardSchema>;
export type Alarm = typeof alarms.$inferSelect;
export type InsertAlarm = z.infer<typeof insertAlarmSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type Timer = typeof timers.$inferSelect;
export type InsertTimer = z.infer<typeof insertTimerSchema>;
