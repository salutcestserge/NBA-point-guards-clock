# Creating a Keystore and Signing Your Android App

This guide walks you through the process of creating a keystore file and using it to sign your Android app.

## Important Warning
**NEVER lose your keystore file or forget the passwords!** If you lose either, you will not be able to update your app on the Google Play Store and would have to publish a new app with a new package name.

## Step 1: Open Android Studio

Run the following command to open your Android project in Android Studio:

```
npx cap open android
```

## Step 2: Generate a Signed Bundle/APK

1. In Android Studio, go to **Build > Generate Signed Bundle/APK**
2. Select **Android App Bundle** or **APK** (Bundle is preferred for Play Store)
3. Click **Next**

## Step 3: Create a New Keystore

1. Select **Create new**
2. For the keystore path, choose: `[project_root]/keystores/android.keystore`
3. Enter a strong password for the keystore
   - **WRITE THIS PASSWORD DOWN AND KEEP IT SECURE**
4. Fill in the Certificate information:
   - Alias: `nbapgclock`
   - Password: (create another strong password)
   - Validity: `25000` (or at least 25 years)
   - Certificate information:
     - First and Last Name: Your name or company name
     - Organizational Unit: Development
     - Organization: NBA PG Clock
     - City: Your city
     - State: Your state
     - Country Code: Your two-letter country code (e.g., US)
5. Click **OK** to generate the keystore

## Step 4: Complete the Signing Configuration

1. Select **release** for Build Variant
2. Check both:
   - **V1 (Jar Signature)**
   - **V2 (Full APK Signature)**
3. Click **Next**

## Step 5: Specify APK Destination Folder

1. Choose a destination folder for your signed APK/Bundle
   - Recommended: `[project_root]/release`
2. Click **Finish**

## Step 6: Wait for Build Completion

Android Studio will now build and sign your app. This may take a few minutes.

## Step 7: Locate Your Signed Bundle/APK

Once the build is complete, you can find your signed Bundle/APK in the destination folder you specified.

## Step 8: Keeping Your Keystore Safe

After creating your keystore, make sure to:
1. Back it up in multiple secure locations (cloud storage, USB drive, etc.)
2. Document your passwords in a secure password manager
3. Never share your keystore or passwords with unauthorized individuals

## Step 9: Update capacitor.config.ts

Ensure the keystore information is correctly set in your capacitor configuration:

```typescript
android: {
  buildOptions: {
    keystorePath: "keystores/android.keystore",
    keystoreAlias: "nbapgclock",
  }
}
```

## Notes for Future App Updates

Always use the same keystore and alias when signing future versions of your app. Losing access to your keystore means you cannot update your existing app on the Google Play Store.