import { 
  users, 
  userSettings,
  alarms,
  timers,
  type User, 
  type InsertUser,
  pointGuards,
  type PointGuard,
  type InsertPointGuard,
  type UserSettings,
  type InsertUserSettings,
  type Alarm,
  type InsertAlarm,
  type Timer,
  type InsertTimer
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Point Guard methods
  getPointGuard(id: number): Promise<PointGuard | undefined>;
  getAllPointGuards(): Promise<PointGuard[]>;
  createPointGuard(pointGuard: InsertPointGuard): Promise<PointGuard>;
  
  // User Settings methods
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: number, settings: Partial<InsertUserSettings>): Promise<UserSettings>;
  
  // Alarm methods
  getAlarms(userId: number): Promise<Alarm[]>;
  getAlarm(id: number): Promise<Alarm | undefined>;
  createAlarm(alarm: InsertAlarm): Promise<Alarm>;
  updateAlarm(id: number, alarm: Partial<InsertAlarm>): Promise<Alarm>;
  deleteAlarm(id: number): Promise<boolean>;
  
  // Timer methods
  getTimers(userId: number): Promise<Timer[]>;
  getTimer(id: number): Promise<Timer | undefined>;
  createTimer(timer: InsertTimer): Promise<Timer>;
  updateTimer(id: number, timer: Partial<InsertTimer>): Promise<Timer>;
  deleteTimer(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private pointGuards: Map<number, PointGuard>;
  private userSettings: Map<number, UserSettings>;
  private alarms: Map<number, Alarm>;
  private timers: Map<number, Timer>;
  
  private currentUserId: number;
  private currentPointGuardId: number;
  private currentAlarmId: number;
  private currentTimerId: number;

  constructor() {
    this.users = new Map();
    this.pointGuards = new Map();
    this.userSettings = new Map();
    this.alarms = new Map();
    this.timers = new Map();
    
    this.currentUserId = 1;
    this.currentPointGuardId = 1;
    this.currentAlarmId = 1;
    this.currentTimerId = 1;
  }

  // User Methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Point Guard Methods
  async getPointGuard(id: number): Promise<PointGuard | undefined> {
    return this.pointGuards.get(id);
  }

  async getAllPointGuards(): Promise<PointGuard[]> {
    return Array.from(this.pointGuards.values());
  }

  async createPointGuard(insertPointGuard: InsertPointGuard): Promise<PointGuard> {
    const id = this.currentPointGuardId++;
    const pointGuard: PointGuard = { ...insertPointGuard, id };
    this.pointGuards.set(id, pointGuard);
    return pointGuard;
  }
  
  // User Settings Methods
  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    const settingsEntries = Array.from(this.userSettings.values());
    return settingsEntries.find(settings => settings.userId === userId);
  }
  
  async createUserSettings(insertSettings: InsertUserSettings): Promise<UserSettings> {
    const id = this.userSettings.size + 1;
    
    // Using type assertion to bypass TypeScript's strict checking
    const settings = { 
      id,
      userId: insertSettings.userId ?? null,
      theme: insertSettings.theme ?? null,
      clockColor: insertSettings.clockColor ?? null,
      hourHandColor: insertSettings.hourHandColor ?? null,
      minuteHandColor: insertSettings.minuteHandColor ?? null,
      secondHandColor: insertSettings.secondHandColor ?? null,
      use24HourFormat: insertSettings.use24HourFormat ?? null,
      showSeconds: insertSettings.showSeconds ?? null
    } as UserSettings;
    
    this.userSettings.set(id, settings);
    return settings;
  }
  
  async updateUserSettings(userId: number, updateData: Partial<InsertUserSettings>): Promise<UserSettings> {
    const existingSettings = await this.getUserSettings(userId);
    
    if (!existingSettings) {
      throw new Error(`No settings found for user with ID ${userId}`);
    }
    
    const updatedSettings: UserSettings = {
      ...existingSettings,
      ...updateData
    };
    
    this.userSettings.set(existingSettings.id, updatedSettings);
    return updatedSettings;
  }
  
  // Alarm Methods
  async getAlarms(userId: number): Promise<Alarm[]> {
    const allAlarms = Array.from(this.alarms.values());
    return allAlarms.filter(alarm => alarm.userId === userId);
  }
  
  async getAlarm(id: number): Promise<Alarm | undefined> {
    return this.alarms.get(id);
  }
  
  async createAlarm(insertAlarm: InsertAlarm): Promise<Alarm> {
    const id = this.currentAlarmId++;
    const now = new Date();
    
    // Using type assertion to bypass TypeScript's strict checking
    const alarm = { 
      id,
      userId: insertAlarm.userId ?? null,
      time: insertAlarm.time,
      label: insertAlarm.label,
      days: insertAlarm.days,
      enabled: insertAlarm.enabled ?? null,
      createdAt: now
    } as Alarm;
    
    this.alarms.set(id, alarm);
    return alarm;
  }
  
  async updateAlarm(id: number, updateData: Partial<InsertAlarm>): Promise<Alarm> {
    const existingAlarm = await this.getAlarm(id);
    
    if (!existingAlarm) {
      throw new Error(`No alarm found with ID ${id}`);
    }
    
    const updatedAlarm: Alarm = {
      ...existingAlarm,
      ...updateData
    };
    
    this.alarms.set(id, updatedAlarm);
    return updatedAlarm;
  }
  
  async deleteAlarm(id: number): Promise<boolean> {
    const exists = this.alarms.has(id);
    if (exists) {
      this.alarms.delete(id);
      return true;
    }
    return false;
  }
  
  // Timer Methods
  async getTimers(userId: number): Promise<Timer[]> {
    const allTimers = Array.from(this.timers.values());
    return allTimers.filter(timer => timer.userId === userId);
  }
  
  async getTimer(id: number): Promise<Timer | undefined> {
    return this.timers.get(id);
  }
  
  async createTimer(insertTimer: InsertTimer): Promise<Timer> {
    const id = this.currentTimerId++;
    const now = new Date();
    
    // Using type assertions to explicitly match the target type
    const timer = {
      id, 
      userId: insertTimer.userId ?? null,
      label: insertTimer.label ?? null,
      duration: insertTimer.duration,
      createdAt: now
    } as Timer;
    
    this.timers.set(id, timer);
    return timer;
  }
  
  async updateTimer(id: number, updateData: Partial<InsertTimer>): Promise<Timer> {
    const existingTimer = await this.getTimer(id);
    
    if (!existingTimer) {
      throw new Error(`No timer found with ID ${id}`);
    }
    
    const updatedTimer: Timer = {
      ...existingTimer,
      ...updateData
    };
    
    this.timers.set(id, updatedTimer);
    return updatedTimer;
  }
  
  async deleteTimer(id: number): Promise<boolean> {
    const exists = this.timers.has(id);
    if (exists) {
      this.timers.delete(id);
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
