# NBA Point Guard Clock - iOS Deployment Guide

This guide will walk you through the complete process of preparing and deploying your NBA Point Guard Clock app to the Apple App Store.

## Prerequisites

Before you begin, make sure you have:

- [ ] Downloaded your complete project
- [ ] A Mac computer (required for iOS development)
- [ ] [Xcode](https://apps.apple.com/us/app/xcode/id497799835) installed (latest version recommended)
- [ ] An [Apple Developer account](https://developer.apple.com/programs/) ($99/year)
- [ ] Enrolled in the Apple Developer Program
- [ ] Basic familiarity with Xcode and iOS development concepts

## Step 1: Prepare Your Environment

1. Install Node.js and npm if you haven't already
2. Open a terminal in your project directory and run:
   ```bash
   npm install
   ```
3. Install the iOS platform for Capacitor:
   ```bash
   npx cap add ios
   ```
4. Build your web app:
   ```bash
   npm run build
   ```
5. Copy web assets to iOS:
   ```bash
   npx cap sync ios
   ```

## Step 2: Open and Configure in Xcode

1. Open your iOS project in Xcode:
   ```bash
   npx cap open ios
   ```
2. In Xcode, click on your project in the navigator
3. Select your project target in the editor
4. Under the "Signing & Capabilities" tab:
   - Connect your Apple Developer account
   - Select your Team
   - Set a unique Bundle Identifier (e.g., `com.yourname.nbapointguardclock`)
   - Xcode should automatically manage signing if configured correctly

## Step 3: Configure App Settings

1. Update app display name, version, and build number:
   - Select your target
   - Go to the "General" tab
   - Set "Display Name" to "NBA PG Clock"
   - Set version (e.g., "1.0.0")
   - Set build number (start with "1")

2. Configure capabilities as needed:
   - Background modes (for alarms)
   - Push notifications
   - App groups (if needed)

3. Update your Info.plist with necessary permissions:
   - Privacy strings for notifications
   - Other required privacy descriptions

## Step 4: Test on a Simulator

1. In Xcode, select a simulator from the device menu
2. Click the "Play" button to build and run
3. Test all app functionality thoroughly
4. Verify that notifications, alarms, and all features work properly

## Step 5: Test on a Physical Device

1. Connect an iOS device to your Mac
2. Select your device from the device menu in Xcode
3. Click "Play" to build and run on your device
4. Test all functionality in real-world conditions
5. Check performance and battery usage

## Step 6: Prepare App Store Assets

Gather the following assets:

1. **App Icon**: App icon set (Xcode will prompt for various sizes)
2. **Screenshots**:
   - iPhone: At least 3 screenshots for each supported device size
   - iPad: At least 3 screenshots (if you support iPad)
3. **App Preview Videos**: Optional but recommended (30-second max)
4. **App Description**: Detailed description (4000 characters max)
5. **Keywords**: Relevant search terms
6. **Support URL**: Link to support website
7. **Marketing URL**: Link to marketing website (optional)
8. **Privacy Policy URL**: Link to your hosted privacy policy (required)

## Step 7: Create App in App Store Connect

1. Go to [App Store Connect](https://appstoreconnect.apple.com/)
2. Click "My Apps"
3. Click the "+" button and select "New App"
4. Fill in the required information:
   - Platforms: iOS
   - Name: "NBA Point Guard Clock"
   - Primary language
   - Bundle ID: Select from dropdown (must match Xcode)
   - SKU: Unique identifier for your app
   - User Access: Full Access
5. Click "Create"

## Step 8: Complete App Store Information

In App Store Connect, fill out all required information:

1. **App Information**: Category, rights, and pricing
2. **iOS App**: Screenshots, preview, description, keywords, support URL, marketing URL
3. **Pricing and Availability**: Price and available countries
4. **App Review Information**: Contact info and login details (if required)
5. **Version Information**: What's new in this version (for updates)
6. **Age Rating**: Complete the questionnaire
7. **App Store Icon and App Name**: Confirm app icon and name

## Step 9: Upload Your Build to App Store Connect

1. In Xcode, select "Generic iOS Device" as the build target
2. Go to Product → Archive
3. When archiving is complete, the Organizer window will appear
4. Select your archive and click "Distribute App"
5. Select "App Store Connect" and click "Next"
6. Select "Upload" and click "Next"
7. Select options for distribution and click "Next"
8. Review your settings and click "Upload"
9. Wait for the upload to complete and processing to finish
10. Verify in App Store Connect that your build appears (may take up to an hour)

## Step 10: Submit for Review

1. In App Store Connect, go to your app
2. Click "iOS App" tab
3. Scroll to "Build" section and select your uploaded build
4. Verify all app information is complete and correct
5. Click "Save" and then "Submit for Review"
6. Answer the export compliance questions
7. Click "Submit"

## Step 11: Monitor Review Status

1. App review typically takes 1-3 days
2. You'll receive emails about the status of your review
3. If rejected, address the issues and resubmit
4. Once approved, you can release immediately or schedule a release date

## Troubleshooting Common Issues

- **Signing issues**: Verify team selection and provisioning profiles
- **Upload failures**: Check bundle ID matches between Xcode and App Store Connect
- **App crashes**: Test thoroughly before submission
- **Rejection reasons**: Carefully read Apple's feedback and address all issues
- **Performance issues**: Test on older devices to ensure good performance

## App Updates

When you want to update your app in the future:

1. Make your changes to the app
2. Increase the build number and version number if needed
3. Archive and upload a new build
4. Update release notes
5. Submit for review

## Important Notes

- Keep your Apple Developer Program membership active to maintain your app in the store
- Follow all [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- Be prepared for rejection and multiple submission attempts for your first app
- Test thoroughly on multiple device types and iOS versions
- Consider supporting the latest iOS version and 1-2 previous versions

## Additional Platform Support

For watchOS, macOS, and iPadOS:

- **watchOS**: Create a watchOS extension in your Xcode project
- **macOS**: Use Catalyst to convert your iPad app to macOS, or create a separate macOS target
- **iPadOS**: Ensure your app is responsive and supports iPad screen sizes

## Resources

- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Capacitor iOS Documentation](https://capacitorjs.com/docs/ios)
- [Apple Developer Documentation](https://developer.apple.com/documentation/)
- [App Store Connect Help](https://help.apple.com/app-store-connect/)