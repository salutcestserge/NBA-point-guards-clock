const CACHE_NAME = 'nba-pg-clock-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/privacy-policy.html',
  '/support.html'
];

// Install event - cache assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        return cache.addAll(ASSETS);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.filter((name) => {
          return name !== CACHE_NAME;
        }).map((name) => {
          return caches.delete(name);
        })
      );
    })
  );
});

// Fetch event - serve from cache when offline
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Return cached response if found
        if (response) {
          return response;
        }

        // Clone the request
        const fetchRequest = event.request.clone();

        // Make network request and cache new resources
        return fetch(fetchRequest)
          .then((response) => {
            // Check if valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone the response
            const responseToCache = response.clone();

            // Cache the new resource
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          })
          .catch(() => {
            // If network request fails and the request is for an image,
            // return a fallback image from the cache
            if (event.request.url.match(/\.(jpg|jpeg|png|gif|svg)$/)) {
              return caches.match('/icons/icon-512x512.png');
            }
          });
      })
  );
});

// Background sync for storing alarms and timers when offline
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-alarms') {
    event.waitUntil(syncAlarms());
  } else if (event.tag === 'sync-timers') {
    event.waitUntil(syncTimers());
  }
});

// Handle push notifications for alarms
self.addEventListener('push', (event) => {
  const data = event.data.json();
  
  const options = {
    body: data.body || 'Time Alert!',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    }
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'NBA PG Clock', options)
  );
});

// Notification click event
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  // This looks to see if the current is open and focuses if it is
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      const hadWindowToFocus = clientList.some((client) => {
        return client.url === event.notification.data.url && 'focus' in client;
      });

      if (hadWindowToFocus) {
        client.focus();
      } else {
        clients.openWindow(event.notification.data.url || '/');
      }
    })
  );
});

// Helper functions for background sync
function syncAlarms() {
  return fetch('/api/alarms/sync')
    .then((response) => response.json());
}

function syncTimers() {
  return fetch('/api/timers/sync')
    .then((response) => response.json());
}