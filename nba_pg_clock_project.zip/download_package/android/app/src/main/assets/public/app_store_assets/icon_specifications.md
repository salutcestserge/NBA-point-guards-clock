# App Icon Specifications for NBA Point Guard Clock

## Apple App Store Icon Requirements

### iOS App Icons
- iPhone App Icon: 1024 x 1024 pixels (App Store) 
- Additional sizes are generated automatically by Apple

### iPad App Icons
- Same as iPhone: 1024 x 1024 pixels

### Apple Watch App Icons
- Apple Watch App Icon: 1024 x 1024 pixels

## Google Play Store Icon Requirements

### App Icon
- Required: High-res icon: 512 x 512 pixels (PNG or JPEG, 32-bit)
- Required: Feature Graphic: 1024 x 500 pixels

### Play Store Asset Guidelines
- Keep the corner radius to 20% of the icon size
- Avoid transparent backgrounds
- Use the full safe zone area
- App icon should be recognizable at small sizes

## Icon Design Guidelines

1. **Design Elements to Include:**
   - Basketball elements (subtle basketball texture or lines)
   - Clock face element
   - NBA-inspired color scheme (without using official NBA logos)
   - Simple, recognizable silhouette that works at small sizes

2. **Color Considerations:**
   - Use high contrast colors that stand out in both light and dark backgrounds
   - Consider using NBA team-inspired blue/red color scheme
   - Ensure the design looks good in both light and dark mode environments

3. **Technical Specifications:**
   - Save as PNG with transparency where needed
   - Use the full canvas space (square format)
   - Create at highest resolution (1024x1024) and scale down for other sizes
   - Test the icon at small sizes for visibility
   - Avoid thin lines that might not be visible at small sizes

4. **Legal Considerations:**
   - Do not use official NBA logos or team logos
   - Avoid using player likenesses that might cause copyright issues
   - Use original artwork rather than copyrighted material

## Naming Pattern for Icon Files

- Use a consistent naming pattern like: `icon_[platform]_[size].png`
- Examples:
  - `icon_ios_1024.png`
  - `icon_android_512.png`
  - `icon_play_feature_graphic.png`

## Design Tools Recommendations

- Adobe Illustrator or Photoshop for vector-based icon creation
- Sketch or Figma for modern icon design
- Icon8 or similar resources for icon elements (with proper licensing)
- Online icon generators that support app icon creation for multiple platforms