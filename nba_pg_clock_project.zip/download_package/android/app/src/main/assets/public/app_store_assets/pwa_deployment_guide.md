# NBA Point Guard Clock - Progressive Web App (PWA) Deployment Guide

This guide will walk you through deploying your NBA Point Guard Clock as a Progressive Web App (PWA), allowing users to install it directly from the web on any platform.

## What is a PWA?

A Progressive Web App provides an app-like experience on the web. PWAs can be installed on devices like mobile phones, tablets, and desktops without going through app stores. They work offline and provide a seamless user experience across all platforms.

## Prerequisites

- Your NBA Point Guard Clock codebase
- A web hosting service (options detailed below)
- Basic knowledge of web deployment

## Step 1: Verify PWA Requirements

Our NBA Point Guard Clock app already has the necessary PWA elements:

1. **Web App Manifest** (`manifest.json`): Contains app metadata like name, icons, and theme colors
2. **Service Worker** (`service-worker.js`): Enables offline functionality and background syncing
3. **HTTPS**: Required for service workers (your hosting must support this)
4. **Responsive Design**: Works on all screen sizes
5. **App Icons**: Various sizes for different devices

## Step 2: Test PWA Functionality Locally

Before deploying, verify all PWA features work:

1. Build your app for production:
   ```bash
   npm run build
   ```

2. Test the production build locally:
   ```bash
   npm run preview
   ```

3. Open Chrome DevTools (F12)
4. Go to "Application" tab → "Manifest" and "Service Workers"
5. Verify the manifest and service worker are detected
6. Test offline functionality:
   - Go to "Network" tab
   - Check "Offline"
   - Refresh the page and confirm it still works
7. Test "Add to Home Screen" functionality

## Step 3: Choose a Hosting Platform

### Option 1: GitHub Pages (Free)

1. Create a GitHub repository
2. Push your `dist` or `build` folder
3. Enable GitHub Pages in repository settings
4. Configure with custom domain if desired

### Option 2: Netlify (Free tier available)

1. Create a Netlify account
2. Connect your GitHub repository
3. Configure build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Deploy

### Option 3: Vercel (Free tier available)

1. Create a Vercel account
2. Import your GitHub repository
3. Configure project settings
4. Deploy

### Option 4: Firebase Hosting (Free tier available)

1. Create a Firebase project
2. Install Firebase CLI:
   ```bash
   npm install -g firebase-tools
   ```
3. Initialize Firebase:
   ```bash
   firebase login
   firebase init hosting
   ```
4. Deploy:
   ```bash
   firebase deploy
   ```

## Step 4: Deploy Your PWA

For this example, we'll use Netlify:

1. Build your production app:
   ```bash
   npm run build
   ```

2. Create a file called `_redirects` in your `public` folder with this content:
   ```
   /*    /index.html   200
   ```
   This ensures proper routing for SPA navigation.

3. Create a `netlify.toml` file in your project root:
   ```toml
   [build]
     publish = "dist"
     command = "npm run build"

   [[headers]]
     for = "/*"
     [headers.values]
       X-Frame-Options = "DENY"
       X-XSS-Protection = "1; mode=block"
       Cache-Control = "public, max-age=86400"
   ```

4. Deploy using the Netlify CLI or website
5. Verify the deployed site works as expected

## Step 5: Optimize Your PWA

1. **Performance**:
   - Use Lighthouse in Chrome DevTools to analyze and improve
   - Aim for scores of 90+ in all categories

2. **Cache Strategy**:
   - Update the service worker to use the most appropriate caching strategy:
     - Cache first for assets
     - Network first for dynamic API data

3. **Offline Experience**:
   - Add a custom offline page
   - Ensure critical functionality works offline

4. **Push Notifications**:
   - Implement push notifications for alarms
   - Request notification permissions at appropriate times

## Step 6: Promote Installation

Add an "Install" button to your web app:

```javascript
// Check if the app can be installed
let deferredPrompt;
const installButton = document.getElementById('install-button');

window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent Chrome from automatically showing the prompt
  e.preventDefault();
  // Stash the event so it can be triggered later
  deferredPrompt = e;
  // Show the install button
  installButton.style.display = 'block';
});

installButton.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  // Show the install prompt
  deferredPrompt.prompt();
  // Wait for the user to respond to the prompt
  const { outcome } = await deferredPrompt.userChoice;
  // Optionally, send analytics about outcome
  console.log(`User response: ${outcome}`);
  // Clear the saved prompt since it can't be used again
  deferredPrompt = null;
  // Hide the install button
  installButton.style.display = 'none';
});

window.addEventListener('appinstalled', (e) => {
  // App is installed, hide the install button
  installButton.style.display = 'none';
  // Optionally, send analytics
  console.log('NBA Point Guard Clock was installed');
});
```

## Step 7: Update Your Privacy Policy

Ensure your privacy policy is accessible from the PWA. Add a link to your privacy policy in the app footer or settings.

## Step 8: Test on Multiple Devices and Browsers

Test your PWA on:
- Android (Chrome, Samsung Internet)
- iOS (Safari)
- Windows (Chrome, Edge)
- macOS (Safari, Chrome)
- Different screen sizes

## Step 9: Update and Maintain

1. **Regular Updates**:
   - When you update your app, build and deploy new version
   - Make sure service worker handles updates properly

2. **Version Management**:
   - Add version number in your app
   - Use service worker to notify users of updates

3. **Analytics**:
   - Implement web analytics to track usage
   - Monitor PWA-specific metrics (installs, offline usage)

## PWA Advantages

- **Cross-platform**: Works on all devices with modern browsers
- **No App Store**: No approval process or fees
- **Always Updated**: Users always get the latest version
- **Discoverable**: Can be found via search engines
- **Installable**: Can be added to home screen
- **Linkable**: Can be shared via URL

## PWA Limitations

- **Limited Device APIs**: Some hardware features may not be accessible
- **iOS Restrictions**: Some PWA features are limited on iOS
- **Background Processing**: More restricted than native apps
- **Discovery**: Less visible than app store apps

## Resources

- [Web.dev PWA Guide](https://web.dev/progressive-web-apps/)
- [MDN PWA Documentation](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
- [Lighthouse Tool](https://developers.google.com/web/tools/lighthouse)
- [PWA Builder](https://www.pwabuilder.com/)