# Google Play Developer Account Setup Guide

This guide walks you through the process of setting up your Google Play Developer account and preparing your NBA Point Guard Clock app for submission.

## Step 1: Create Google Play Developer Account

1. **Visit the Google Play Console**
   - Go to [play.google.com/console/signup](https://play.google.com/console/signup)
   - Sign in with your Google account (or create one if needed)

2. **Accept Developer Agreement**
   - Read and accept the Google Play Developer distribution agreement
   - This agreement covers your responsibilities as an app developer

3. **Pay Registration Fee**
   - Pay the one-time $25 USD registration fee
   - This fee is required to publish apps on Google Play
   - Payment can be made via credit/debit card or other accepted methods

4. **Complete Account Details**
   - **Developer Name**: This will be visible to users (e.g., "NBA Clock Apps")
   - **Contact Email**: For Google to contact you regarding your account
   - **Contact Phone**: Required for account verification
   - **Developer Address**: Your physical business address

5. **Verify Your Account**
   - Complete phone verification if prompted
   - Verify your email address

## Step 2: Set Up Your Developer Profile

1. **Access Developer Profile**
   - In Google Play Console, go to Settings → Developer account → Account details

2. **Complete Required Information**
   - **External links**: Add your website, privacy policy URL
   - **Developer ID**: Confirm your public developer name

3. **Set Up Payments Profile (if applicable)**
   - If you plan to sell apps or offer in-app purchases:
     - Go to Settings → Developer account → Payments profile
     - Add your tax information
     - Set up your merchant account
     - Add banking details for receiving payments

## Step 3: Create Your App Listing

1. **Start New App**
   - In Google Play Console, click "Create app"
   - Select default language
   - Enter app name: "NBA Point Guard Clock"
   - Specify free or paid (recommended: free)
   - Confirm you comply with developer policies
   - Click "Create app"

2. **Dashboard Navigation**
   - After creating your app, you'll be taken to the app dashboard
   - Navigate using the left sidebar menu

## Step 4: Prepare Store Listing

1. **Store Listing Section**
   - Go to "Store presence" → "Store listing"

2. **Complete App Details**
   - **App name**: "NBA Point Guard Clock" (max 50 characters)
   - **Short description**: Brief, engaging summary (max 80 characters)
     - Example: "Basketball-themed clock featuring NBA's greatest point guards with alarms & timers"
   
   - **Full description**: Detailed app description (max 4000 characters)
     - Include key features, benefits, and unique selling points
     - Use formatting (line breaks, bullet points) for readability
     - Include keywords naturally for better search visibility

3. **Add Visual Assets**
   - **App icon**: Upload your 512×512px icon (PNG or JPEG)
   - **Feature graphic**: Upload 1024×500px promotional banner
   - **Screenshots**:
     - Phone screenshots (min 2, max 8) in 16:9 aspect ratio
     - Tablet screenshots if supporting tablets
     - Each screenshot should showcase a key feature

4. **Categorization & Tags**
   - **App category**: Select "Tools" or "Productivity"
   - **Tags**: Add relevant tags like "clock," "basketball," "NBA," "alarm"

5. **Contact Information**
   - Add email address for user support
   - Add phone number (optional)
   - Add website URL

## Step 5: App Content & Privacy

1. **Content Rating**
   - Go to "Store presence" → "Content rating"
   - Complete the questionnaire honestly
   - For a clock app, you'll likely receive an "Everyone" rating

2. **Target Audience**
   - Go to "Store presence" → "Target audience"
   - Specify target age groups
   - Indicate if your app appeals to children

3. **Privacy Policy**
   - Upload your privacy policy URL
   - This must be a live URL, not a local file
   - Ensure the policy covers all data your app collects
   - Remember to host the privacy policy we've prepared at `client/public/app_store_assets/privacy_policy.md` on your website

## Step 6: App Release Management

1. **Go to "Production" Section**
   - In the left sidebar, click on "Production"

2. **Create New Release**
   - Click "Create new release"
   - This is where you'll upload your app bundle or APK

3. **Upload App Bundle**
   - Drag and drop your signed AAB file (recommended) or APK
   - AAB is preferred as it optimizes the app for different devices
   - You can generate this using the `build-signed-apk.sh` script we created

4. **Release Notes**
   - Add "What's new in this release" information
   - For first release, you can describe initial features

5. **Review Release**
   - Review all information for accuracy
   - Check for any warnings or errors that need addressing

## Step 7: Configure Store Settings

1. **Pricing & Distribution**
   - Go to "Store presence" → "Pricing & distribution"
   - Select countries where your app will be available
   - Mark your app as free or paid
   - Set specific price by country if paid

2. **App Availability**
   - Specify if your app should be available to all Google Play users
   - Set minimum Android version requirements (if different from your build)

3. **Additional Advanced Settings**
   - Under "Advanced settings," configure options like:
     - Device compatibility
     - App updates preferences
     - Pre-launch reporting

## Step 8: Review & Submit

1. **Final Review**
   - Go through each section in the left sidebar
   - Check for any items marked as "Required" or with warning icons
   - Ensure all required information is completed

2. **Submit for Review**
   - Once all sections are complete, return to the "Production" tab
   - Click "Review release" then "Start rollout to Production"
   - Your app will enter the review queue

3. **Track Review Status**
   - Monitor your email for updates from Google
   - Check the Play Console for review status
   - Typical review time is 1-3 days for new apps

## After Submission

1. **Monitor Performance**
   - Use the Google Play Console dashboard to track:
     - Installations
     - Ratings and reviews
     - Crashes and ANRs (Application Not Responding)
     - User acquisition

2. **Prepare for Updates**
   - Keep track of user feedback for future improvements
   - Plan regular updates to fix bugs and add features
   - Remember to increment `versionCode` in build.gradle for each update

3. **Respond to Reviews**
   - Actively respond to user reviews
   - Address issues mentioned in negative reviews
   - Thank users for positive feedback

## Tips for Approval

1. **Test thoroughly** before submission to avoid rejections
2. **Comply with all policies** to prevent violations
3. **Use high-quality images** for better store presence
4. **Be honest in descriptions** and only promise features that exist
5. **Ensure your privacy policy** properly discloses all data use

---

*Once your Google Play Developer account is set up and your app is submitted, you can start preparing for other platforms like iOS, macOS, and watchOS using our other deployment guides.*