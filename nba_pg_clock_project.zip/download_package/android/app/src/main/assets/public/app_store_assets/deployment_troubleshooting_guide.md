# NBA Point Guard Clock - Deployment Troubleshooting Guide

This guide addresses common issues you might encounter when deploying your NBA Point Guard Clock app to various platforms.

## Android Deployment Issues

### Build Failures

#### Gradle Build Errors
- **Issue**: Build fails with Gradle errors
- **Solution**: 
  1. Check your `android/build.gradle` and `android/app/build.gradle` files
  2. Make sure you have the latest Gradle version compatible with your Android project
  3. Try running `./gradlew clean` in the android directory
  4. Verify dependencies don't have conflicts

#### Keystore Issues
- **Issue**: "Keystore file not found" or signing errors
- **Solution**:
  1. Verify the keystore path in `capacitor.config.ts` is correct
  2. Check that the keystore file exists at `keystores/android.keystore`
  3. Confirm the password and alias are correct
  4. If using command line, ensure the full path to the keystore is provided

#### Resource Errors
- **Issue**: Missing resource errors
- **Solution**:
  1. Run `npx cap sync android` to update Android resources
  2. Check for any missing files in the android/app/src/main/res directory
  3. Verify XML resource files are properly formatted

### Google Play Submission Issues

#### Rejection Reasons
- **Issue**: App rejected by Google Play
- **Solution** (for common rejections):
  1. **Metadata issues**: Ensure screenshots, descriptions, and other metadata match your app
  2. **Content policy violations**: Review Google's policies and update your content
  3. **Functionality issues**: Fix crashes or non-functioning features
  4. **Permission issues**: Only request permissions that are necessary
  5. **Privacy policy**: Ensure your privacy policy is comprehensive and accessible

#### App Bundle Issues
- **Issue**: App Bundle (AAB) not accepted
- **Solution**:
  1. Ensure your AAB is signed with the release key, not debug
  2. Update Gradle plugin to the latest version
  3. Check minimum API level meets Google Play requirements

## iOS Deployment Issues

### Xcode Build Errors

#### Code Signing Issues
- **Issue**: "Code signing failed" errors
- **Solution**:
  1. Verify your Apple Developer account is active
  2. Check that your provisioning profile and certificates are valid
  3. Try letting Xcode manage signing automatically (check "Automatically manage signing")
  4. Refresh provisioning profiles in Xcode

#### iOS Version Compatibility
- **Issue**: Errors about iOS version compatibility
- **Solution**:
  1. Check your minimum iOS version in Xcode project settings
  2. Update any deprecated API usage
  3. Test on devices running your minimum supported iOS version

#### Missing Resources
- **Issue**: Resources not found in the app
- **Solution**:
  1. Run `npx cap sync ios` to update iOS resources
  2. Check that all assets are included in the Xcode project
  3. Verify asset catalogs are properly configured

### App Store Submission Issues

#### Rejection Reasons
- **Issue**: App rejected by App Store Review
- **Solution** (for common rejections):
  1. **Incomplete information**: Provide test accounts if your app requires login
  2. **Crashes and bugs**: Fix all crashes before submission
  3. **Privacy concerns**: Update privacy usage descriptions and policy
  4. **Design issues**: Ensure your UI follows Apple's Human Interface Guidelines
  5. **Metadata issues**: Make sure screenshots and descriptions accurately represent your app

#### Transporter Errors
- **Issue**: Unable to upload binary via Transporter or Xcode
- **Solution**:
  1. Check internet connection
  2. Verify the Apple ID used has correct permissions
  3. Try uploading from a different network
  4. Try both Xcode and Transporter app for uploading

## macOS & watchOS Issues

### Mac Catalyst Issues
- **Issue**: UI elements don't appear correctly on macOS
- **Solution**:
  1. Add macOS-specific UI adjustments using platform checks
  2. Test window resizing behavior
  3. Implement proper keyboard shortcuts
  4. Check for touch-dependent interactions that need mouse alternatives

### watchOS Complications
- **Issue**: Watch complications not updating
- **Solution**:
  1. Verify complication descriptors are correctly configured
  2. Check timeline entries are properly scheduled
  3. Test with ClockKit debugging enabled
  4. Ensure complication templates are appropriate for the selected families

## Web/PWA Deployment Issues

### Service Worker Issues
- **Issue**: Offline functionality not working
- **Solution**:
  1. Verify service worker is registered successfully
  2. Check service worker scope
  3. Ensure your site is served over HTTPS
  4. Check browser console for service worker errors
  5. Validate cache strategy implementation

### Manifest Problems
- **Issue**: PWA not installable
- **Solution**:
  1. Verify web manifest is properly linked in HTML
  2. Check manifest.json for required fields (icons, name, display, etc.)
  3. Ensure icons are available in required sizes
  4. Test with Lighthouse's PWA audit
  5. Verify HTTPS is properly configured

### Cross-Browser Issues
- **Issue**: PWA works in Chrome but not other browsers
- **Solution**:
  1. Test in multiple browsers
  2. Use feature detection instead of browser detection
  3. Implement polyfills for missing browser features
  4. Check for browser-specific CSS issues

## Capacitor-Specific Issues

### Plugin Issues
- **Issue**: Capacitor plugins not working correctly
- **Solution**:
  1. Check plugin versions are compatible with your Capacitor version
  2. Run `npx cap sync` after installing or updating plugins
  3. Verify native configurations for plugins (e.g., info.plist entries, AndroidManifest.xml)
  4. Check console for plugin-specific errors

### Native Project Sync Issues
- **Issue**: Changes not reflecting in native projects
- **Solution**:
  1. Run `npm run build` before `npx cap sync`
  2. Check capacitor.config.ts configuration
  3. Verify webDir setting points to the correct build output directory
  4. For major changes, try `npx cap copy` followed by `npx cap update`

## General Troubleshooting

### Identifying Issues
1. Check console logs for errors
2. Look for build output messages
3. Test on different devices to isolate device-specific issues
4. Use platform-specific debugging tools:
   - Android: Logcat in Android Studio
   - iOS: Console in Xcode
   - Web: Browser DevTools

### Common Fixes
1. **Clean and Rebuild**:
   - Web: Clear browser cache
   - Android: `./gradlew clean` in Android directory
   - iOS: Clean build folder in Xcode (⇧⌘K)

2. **Dependency Issues**:
   - Update Capacitor and plugins to compatible versions
   - Check for conflicting dependencies
   - Verify native dependencies are properly configured

3. **Configuration Issues**:
   - Double-check all platform-specific configurations
   - Verify environment variables are correctly set
   - Check for typos in configuration files

## Getting Help

If you continue to experience issues after trying these solutions:

1. **Capacitor Community**:
   - [Capacitor Forum](https://forum.ionicframework.com/c/capacitor)
   - [Capacitor GitHub](https://github.com/ionic-team/capacitor/issues)

2. **Platform-Specific Resources**:
   - [Google Play Console Help](https://support.google.com/googleplay/android-developer)
   - [Apple Developer Forums](https://developer.apple.com/forums/)

3. **Stack Overflow**:
   - Search with relevant tags: capacitor, android, ios, pwa
   - Provide detailed information when asking questions

4. **Professional Support**:
   - Consider hiring a developer with specific platform expertise
   - Ionic offers professional support for Capacitor

## Preventative Measures

To minimize deployment issues in future updates:

1. Keep all native project files under version control
2. Document any manual changes made to native projects
3. Test thoroughly on all target platforms before submission
4. Create a CI/CD pipeline for consistent builds
5. Maintain separate development, staging, and production environments
6. Keep your keystore and certificates backed up securely

---

*Remember: When making significant changes to your app, test thoroughly on all target platforms before submitting updates to app stores.*