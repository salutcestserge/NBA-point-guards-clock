# App Store Screenshot Specifications Guide

This document provides the required specifications for creating screenshots for the NBA Point Guard Clock app submission to both the Apple App Store and Google Play Store.

## Apple App Store Screenshot Requirements

### Required Device Screenshots
For iOS apps, Apple requires screenshots for these devices:
- 6.5-inch iPhone (iPhone 11 Pro Max, iPhone XS Max)
- 5.5-inch iPhone (iPhone 8 Plus, iPhone 7 Plus)
- iPad Pro (12.9-inch) (3rd generation)

### Screenshot Dimensions
| Device                           | Portrait Size (pixels) | Landscape Size (pixels) |
|----------------------------------|------------------------|-------------------------|
| 6.5" iPhone (iPhone 11 Pro Max)  | 1242 × 2688           | 2688 × 1242            |
| 5.5" iPhone (iPhone 8 Plus)      | 1242 × 2208           | 2208 × 1242            |
| 12.9" iPad Pro (3rd generation)  | 2048 × 2732           | 2732 × 2048            |

### Screenshot Quantity
- Minimum: 1 screenshot per device size
- Maximum: 10 screenshots per device size

### Format Requirements
- File format: JPG or PNG
- Color space: RGB (not CMYK)
- No alpha channel
- 72 dpi resolution recommended

## Google Play Store Screenshot Requirements

### Required Screenshots
For Android apps, Google requires:
- At least 2 screenshots
- Maximum of 8 screenshots per device type

### Screenshot Dimensions
| Screenshot Type     | Dimensions (pixels) | Aspect Ratio   |
|---------------------|---------------------|----------------|
| Phone               | Minimum 320 width   | 16:9, 9:16     |
|                     | Maximum 3840 height |                |
| 7-inch tablet       | Minimum 320 width   | 16:9, 9:16     |
|                     | Maximum 3840 height |                |
| 10-inch tablet      | Minimum 320 width   | 16:9, 9:16     |
|                     | Maximum 3840 height |                |

### Feature Graphic
- Dimensions: 1024 × 500 pixels
- File format: PNG or JPG (no alpha)
- Important visual elements should be within safe area (center 80% of graphic)

### Format Requirements
- File format: JPG or PNG (24-bit, no alpha)
- File size: Maximum 8MB per image
- No borders or device frames

## Recommended Screenshots to Showcase

For the NBA Point Guard Clock app, create screenshots highlighting these key features:

1. **Main Clock View**
   - Show the clock with all 12 point guard positions filled
   - Highlight the dynamic team color background
   - Include clock hands in a visually appealing position

2. **Player Details View**
   - Demonstrate the hover/tap functionality showing player stats
   - Include notable stats and achievements for a recognizable player

3. **Alarms Feature**
   - Show the alarm setup interface
   - Include a list of existing alarms
   - Highlight basketball-themed sound options

4. **Timer/Stopwatch**
   - Display the timer countdown interface
   - Alternatively, show the stopwatch with lap times

5. **World Clock**
   - Show multiple time zones with basketball relevance
   - Highlight the clean interface for managing multiple clocks

6. **Settings/Customization**
   - Display the theme selection options
   - Show color customization for clock hands
   - Demonstrate dark/light mode toggle

## Screenshot Design Guidelines

- Include clear feature callouts with short text descriptions
- Use consistent branding elements across all screenshots
- Ensure text is legible at smaller sizes
- Avoid cluttering with too many UI elements
- Make sure content accurately represents the actual app
- Use app-specific content (basketball related imagery and text)

## Localization Considerations

If submitting to multiple regions:
- Create localized screenshots for each supported language
- Ensure translations are accurate and culturally appropriate
- Maintain consistent layout across language versions

## Screenshot Creation Tools

Recommended tools for creating app store screenshots:
- Adobe Photoshop or Illustrator
- Sketch
- Figma
- Screenshot generation tools like Fastlane's "snapshot"

## Final Checklist Before Submission

- All screenshots meet dimensional requirements
- No transparent backgrounds or alpha channels
- File sizes are under the maximum limit
- All text is clearly legible
- Screenshots accurately represent the app
- No placeholder or debugging elements visible
- Consistent branding across all images