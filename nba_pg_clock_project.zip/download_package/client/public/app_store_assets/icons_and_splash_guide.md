# NBA Point Guard Clock - Icons and Splash Screen Guide

This guide will help you prepare professional app icons and splash screens for your NBA Point Guard Clock Android app.

## Android App Icon Requirements

### Icon Dimensions
For Android, you need to provide icons in multiple resolutions:

| Density | Dimensions | Location in Project |
|---------|------------|---------------------|
| mdpi    | 48×48 px   | android/app/src/main/res/mipmap-mdpi/ic_launcher.png |
| hdpi    | 72×72 px   | android/app/src/main/res/mipmap-hdpi/ic_launcher.png |
| xhdpi   | 96×96 px   | android/app/src/main/res/mipmap-xhdpi/ic_launcher.png |
| xxhdpi  | 144×144 px | android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png |
| xxxhdpi | 192×192 px | android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png |
| Play Store | 512×512 px | (For Google Play listing) |

### Icon Design Guidelines
1. **Keep it simple** - Use clean shapes that are recognizable at small sizes
2. **Use your brand colors** - Incorporate the NBA team colors from your app
3. **Add padding** - Leave about 10% padding around your design
4. **Consistency** - Ensure your icon matches your app's design language
5. **No transparency** in the icon itself (the adaptive icon background can have transparency)

### Adaptive Icons (Android 8.0+)
For modern Android devices, create adaptive icons with:
- Foreground layer: Your main icon content
- Background layer: A solid color or simple pattern

## Splash Screen Guidelines

Capacitor automatically creates a splash screen using your app icon. For a custom splash:

1. **Create splash image**:
   - Create a PNG image centered on a transparent background
   - Recommended size: 1200×1200 px (will be scaled down)
   - Keep important content within center 80% of the image

2. **Update splash screen configuration**:
   Edit `capacitor.config.ts` to customize splash screen behavior:

```typescript
plugins: {
  SplashScreen: {
    launchShowDuration: 2000, // How long to show splash screen in ms
    launchAutoHide: true,
    backgroundColor: "#FFFFFF", // Background color
    androidSplashResourceName: "splash", // Image file name in resources
    androidScaleType: "CENTER_CROP",
    showSpinner: true,
    androidSpinnerStyle: "large",
    spinnerColor: "#999999",
  },
}
```

3. **Place splash image files** in resolution-specific folders:

| Density | Dimensions | Location in Project |
|---------|------------|---------------------|
| mdpi    | 320×480 px | android/app/src/main/res/drawable-port-mdpi/splash.png |
| hdpi    | 480×800 px | android/app/src/main/res/drawable-port-hdpi/splash.png |
| xhdpi   | 720×1280 px | android/app/src/main/res/drawable-port-xhdpi/splash.png |
| xxhdpi  | 960×1600 px | android/app/src/main/res/drawable-port-xxhdpi/splash.png |
| xxxhdpi | 1280×1920 px | android/app/src/main/res/drawable-port-xxxhdpi/splash.png |

## Creating App Icons and Splash Screens

### Option 1: Using Online Tools

1. **Capacitor Assets Tool**:
   - Visit [Capacitor Assets](https://capacitorjs.com/docs/guides/splash-screens-and-icons)
   - Upload your high-resolution icon and splash image
   - Download generated assets

2. **Android Asset Studio**:
   - Visit [Android Asset Studio](https://romannurik.github.io/AndroidAssetStudio/index.html)
   - Use the "Launcher Icon Generator" and "Notification Icon Generator"
   - Download and place in your project

### Option 2: Using Design Software

1. **Create your base designs** in Adobe Illustrator, Photoshop, or similar
2. **Export at multiple resolutions** following the tables above
3. **Place files** in the appropriate project directories

## NBA-Themed Icon Design Ideas

For your NBA Point Guard Clock app, consider these icon design approaches:

1. **Clock with basketball elements**:
   - Clock face with basketball texture
   - Hour/minute hands shaped like basketball players

2. **Basketball with clock elements**:
   - Basketball with clock numbers
   - Basketball with clock hands overlaid

3. **Player silhouette**:
   - Famous point guard silhouette
   - Combined with clock elements

4. **Team colors approach**:
   - Use team color gradients
   - Incorporate team logo elements subtly

## Testing Your Icons and Splash Screen

1. **Test on multiple devices** with different screen sizes
2. **Check different Android versions** if possible
3. **Verify splash screen timing** is appropriate (not too long or short)
4. **Test against light and dark backgrounds** to ensure visibility

## Implementing Your Custom Icons and Splash Screen

1. **Add icon files** to the appropriate directories
2. **Update capacitor.config.ts** with splash screen preferences
3. **Sync your project**:
   ```bash
   npx cap sync android
   ```
4. **Test the application** with your new assets

---

*Having professional icons and splash screens will significantly improve users' first impression of your NBA Point Guard Clock app and increase the likelihood of favorable reviews.*