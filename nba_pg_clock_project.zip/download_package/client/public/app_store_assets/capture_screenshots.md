# Capturing Perfect Screenshots for Google Play Store

High-quality screenshots are essential for your NBA Point Guard Clock app listing. This guide provides practical methods for capturing perfect screenshots.

## Method 1: Using Android Studio's Built-in Tools

Android Studio offers a convenient way to capture screenshots during testing:

1. Open your app in Android Studio with a connected device
2. Navigate to the screen you want to capture
3. Click on "View" in the menu bar
4. Select "Tool Windows" → "Device File Explorer"
5. Take a screenshot by clicking the camera icon in the Device File Explorer toolbar
6. The screenshot will be saved on your computer

## Method 2: Using ADB (Android Debug Bridge)

ADB provides a command-line method to capture screenshots:

1. Connect your device via USB and enable USB debugging
2. Open a terminal/command prompt
3. Run:
   ```
   adb shell screencap -p /sdcard/screenshot.png
   adb pull /sdcard/screenshot.png
   ```
4. The screenshot will be saved to your current directory

## Method 3: Using Device Screenshots + File Transfer

The simplest method for most users:

1. Navigate to the screen you want to capture in your app
2. Take a screenshot using your device's built-in method:
   - Most Android devices: Press Volume Down + Power buttons simultaneously
   - Samsung devices: Press Volume Down + Power, or swipe the side of your hand across the screen
3. Connect your device to your computer
4. Transfer the screenshots from your device's DCIM/Screenshots folder

## Method 4: Screen Recording for Dynamic Features

For features that involve animation:

1. On your device, open Quick Settings (swipe down twice from top)
2. Tap "Screen Record" (if available) or install a screen recording app
3. Record a short video demonstrating the feature
4. Extract key frames from the video using video editing software

## Enhancing Your Screenshots for the Play Store

### Using Device Frames

1. Visit the [Device Art Generator](https://developer.android.com/distribute/marketing-tools/device-art-generator)
2. Upload your raw screenshots
3. Choose a device frame that matches your testing device
4. Download the framed screenshots

### Adding Text Overlays and Annotations

Use design tools to add explanatory text:

1. Import screenshots into Photoshop, GIMP, or Canva
2. Add short feature descriptions (e.g., "View player stats with a single tap")
3. Use arrows or highlights to draw attention to key features
4. Maintain consistent styling across all screenshots

### Screen Setup for Great Screenshots

Before capturing, make sure to:

1. Use the app in a location with good lighting (for any camera views)
2. Set the device time to showcase different NBA players at different hours
3. Clean up any test data or incomplete features
4. Use a neutral or gradient wallpaper if the app background is transparent
5. Consider setting device to English for screenshots (unless targeting other languages)

## Recommended Screenshots for NBA Point Guard Clock

For the best presentation, capture these screens:

1. **Main Clock View**: Show the complete clock with all 12 NBA point guards visible
2. **Player Info View**: Show the stats popup when tapping on a famous player
3. **Alarm Setup**: Show the interface for setting up an alarm
4. **Team Color Transition**: If possible, capture the background changing colors
5. **Timer Feature**: Show the timer in action
6. **Stopwatch**: Display the stopwatch with lap times
7. **World Clock**: Show multiple time zones set up
8. **Settings Screen**: Display customization options

## Creating a Screenshot Script

For efficient capturing, create a testing script to follow:

1. Fresh install the app on a test device
2. Systematically navigate to each key screen
3. Configure each screen optimally before capturing
4. Use consistent device orientation (portrait recommended)
5. Capture each screenshot in a single session for consistency

## Technical Requirements for Google Play

Ensure your final screenshots meet these specifications:

- JPEG or 24-bit PNG (no alpha)
- Minimum dimension: 320px
- Maximum dimension: 3840px
- Aspect ratio can't be more than 2:1
- Required: At least 2 screenshots
- Maximum: 8 screenshots per device type

## Organizing Your Screenshots

Keep your screenshots organized:

1. Create separate folders for:
   - Phone screenshots
   - 7-inch tablet screenshots (if supporting tablets)
   - 10-inch tablet screenshots (if supporting tablets)

2. Name files clearly:
   - `nba_clock_main_view.png`
   - `nba_clock_player_stats.png`
   - `nba_clock_alarm_setup.png`
   etc.

3. Keep both originals and edited versions

---

*Having professional, well-composed screenshots dramatically increases your app's appeal in the Google Play Store and can significantly improve download rates.*