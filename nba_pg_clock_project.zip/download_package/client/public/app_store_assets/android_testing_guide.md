# NBA Point Guard Clock - Android Testing Guide

This comprehensive guide will walk you through testing your NBA Point Guard Clock app on Android devices, from building the APK to conducting detailed tests.

## Method 1: USB Testing with Android Studio

### Prerequisites
- Computer with Android Studio installed
- USB cable
- Android device

### Step 1: Enable Developer Options on Your Device
1. Open **Settings** on your Android device
2. Scroll down and tap **About phone** (or **About device**)
3. Find **Build number** and tap it 7 times
4. You'll see a message "You are now a developer!"
5. Go back to main **Settings** and find the new **Developer options** section
6. Enable **USB debugging** in Developer options

### Step 2: Connect Your Device
1. Connect your Android device to your computer with a USB cable
2. On your device, you'll see a prompt asking to "Allow USB debugging" - tap **Allow**
3. If prompted, select to trust this computer

### Step 3: Open and Run in Android Studio
1. In your terminal, run:
   ```
   npx cap open android
   ```
2. Once Android Studio opens:
   - Look for the device dropdown in the toolbar
   - Select your connected device
   - Click the green "Run" button (triangle play icon)
3. Wait for the app to build and install on your device

## Method 2: Installing APK Directly

If you don't have Android Studio or prefer a quicker method:

### Step 1: Build the Debug APK
1. Make the script executable (one-time setup):
   ```
   chmod +x build-debug-apk.sh
   ```
2. Run the script:
   ```
   ./build-debug-apk.sh
   ```
3. The APK will be created at `builds/android/nba-pg-clock-debug.apk`

### Step 2: Transfer APK to Your Device
Choose one of these methods:

**Option A: Using ADB (Android Debug Bridge)**
1. Enable Developer Options and USB Debugging as described above
2. Connect your device via USB
3. Install ADB on your computer if you don't have it
4. Run:
   ```
   adb install builds/android/nba-pg-clock-debug.apk
   ```

**Option B: Transfer File**
1. Connect your device via USB in file transfer mode
2. Copy the APK to your device's storage
3. On your device, use a file manager to navigate to the APK
4. Enable "Install from unknown sources" in Settings > Security
5. Tap the APK file to install

**Option C: Email or Cloud Service**
1. Email the APK to yourself
2. Open the email on your Android device
3. Download and tap to install
4. Alternatively, upload to Google Drive or Dropbox and download from there

## Method 3: Testing on Multiple Devices with Firebase

For more extensive testing across devices:

1. Create a Firebase project
2. Set up Firebase App Distribution
3. Upload your APK 
4. Add tester email addresses
5. Testers will receive email invitations with download links

## Comprehensive Testing Checklist

### Basic Functionality
- [ ] App launches without crashing
- [ ] Main clock screen displays properly
- [ ] Clock hands move at the correct speed
- [ ] Each hour position shows a different NBA point guard
- [ ] Tapping on a player shows their information
- [ ] Background color changes based on the hour

### Alarms
- [ ] Can create a new alarm
- [ ] Can edit existing alarms
- [ ] Can delete alarms
- [ ] Alarms trigger at the set time
- [ ] Alarm notifications appear correctly
- [ ] Snooze and dismiss functions work

### Timers
- [ ] Can create and start timers
- [ ] Pause/resume functions work
- [ ] Timer completes and notifies correctly
- [ ] Multiple timers function independently

### Stopwatch
- [ ] Starts, stops, and resets correctly
- [ ] Lap time function works
- [ ] Display remains accurate during long periods

### World Clock
- [ ] Can add different time zones
- [ ] Times update correctly
- [ ] Can remove time zones

### Device-Specific Testing
- [ ] Test in both portrait and landscape orientation
- [ ] Test with different system font sizes
- [ ] Check on different screen sizes (if multiple devices available)
- [ ] Test with dark mode enabled/disabled

### Performance Testing
- [ ] App remains responsive during use
- [ ] Animations are smooth
- [ ] No noticeable delay when interacting with UI
- [ ] Check memory usage in Developer Options

### Background Behavior
- [ ] Put app in background and return - should maintain state
- [ ] Alarms should trigger even when app is closed
- [ ] Check battery usage after extended use

## Troubleshooting Common Issues

### App Crashes on Launch
- Check Android Studio Logcat for error messages
- Verify the device meets minimum requirements
- Try clearing app data and cache

### Display Issues
- Check different devices/screen sizes if possible
- Verify layout constraints are working correctly
- Test different system font sizes

### Notification Problems
- Check notification permissions in device settings
- Verify the app has proper background running permissions
- Test with different Android versions if possible

### Performance Issues
- Close other apps running in the background
- Watch memory usage in Developer Options
- Check for CPU-intensive loops or operations

## Gathering Feedback

During testing, document the following:
1. Device make and model
2. Android version
3. Steps to reproduce any issues
4. Screenshots of problems
5. Logcat output for crashes (if using Android Studio)

## Next Steps After Testing

1. Fix any issues identified during testing
2. Once stable, build a signed release APK using:
   ```
   ./build-signed-apk.sh
   ```
3. Test the release version before submitting to Google Play
4. Complete the pre-launch checklist

---

*This testing guide ensures your NBA Point Guard Clock app is thoroughly tested before submission to the Google Play Store, increasing the chances of a successful launch and positive user experience.*