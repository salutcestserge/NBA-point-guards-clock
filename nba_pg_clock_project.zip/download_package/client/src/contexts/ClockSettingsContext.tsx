import React, { createContext, useContext, useEffect, useState } from 'react';
import { apiRequest } from '@/lib/queryClient';

interface ClockSettings {
  theme: string;
  clockColor: string;
  hourHandColor: string;
  minuteHandColor: string;
  secondHandColor: string;
  use24HourFormat: boolean;
  showSeconds: boolean;
  soundTheme: string;
  alarmSound: string;
  timerSound: string;
  hasCustomSounds: boolean;
  darkMode: boolean;
}

// Temporary default user ID (in a real app, this would come from authentication)
const DEFAULT_USER_ID = 1;

interface ClockSettingsContextType {
  settings: ClockSettings;
  isLoading: boolean;
  error: Error | null;
  updateSettings: (newSettings: Partial<ClockSettings>) => Promise<void>;
}

const defaultSettings: ClockSettings = {
  theme: 'default',
  clockColor: '#343A40',
  hourHandColor: '#1E40AF',
  minuteHandColor: '#343A40',
  secondHandColor: '#DC2626',
  use24HourFormat: false,
  showSeconds: true,
  soundTheme: 'basic',
  alarmSound: 'digital',
  timerSound: 'beep',
  hasCustomSounds: false,
  darkMode: false,
};

const ClockSettingsContext = createContext<ClockSettingsContextType>({
  settings: defaultSettings,
  isLoading: false,
  error: null,
  updateSettings: async () => {},
});

export const useClockSettings = () => useContext(ClockSettingsContext);

export const ClockSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<ClockSettings>(defaultSettings);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  // Fetch settings on mount
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setIsLoading(true);
        
        try {
          const response = await fetch(`/api/settings/${DEFAULT_USER_ID}`);
          if (response.ok) {
            const data = await response.json();
            setSettings({
              theme: data.theme || defaultSettings.theme,
              clockColor: data.clockColor || defaultSettings.clockColor,
              hourHandColor: data.hourHandColor || defaultSettings.hourHandColor,
              minuteHandColor: data.minuteHandColor || defaultSettings.minuteHandColor,
              secondHandColor: data.secondHandColor || defaultSettings.secondHandColor,
              use24HourFormat: data.use24HourFormat !== undefined 
                ? data.use24HourFormat 
                : defaultSettings.use24HourFormat,
              showSeconds: data.showSeconds !== undefined 
                ? data.showSeconds 
                : defaultSettings.showSeconds,
              soundTheme: data.soundTheme || defaultSettings.soundTheme,
              alarmSound: data.alarmSound || defaultSettings.alarmSound,
              timerSound: data.timerSound || defaultSettings.timerSound,
              hasCustomSounds: data.hasCustomSounds !== undefined
                ? data.hasCustomSounds
                : defaultSettings.hasCustomSounds,
              darkMode: data.darkMode !== undefined
                ? data.darkMode
                : defaultSettings.darkMode,
            });
          } else {
            // If settings don't exist yet, we'll use defaults and not show an error
            console.log('No settings found, using defaults');
          }
        } catch (err) {
          // API endpoint might not exist yet, so just use defaults
          console.log('Using default settings');
        }
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch settings'));
        console.error('Error fetching clock settings:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSettings();
  }, []);

  const updateSettings = async (newSettings: Partial<ClockSettings>) => {
    try {
      setIsLoading(true);
      const updatedSettings = { ...settings, ...newSettings };
      
      const response = await fetch(`/api/settings/${DEFAULT_USER_ID}`, {
        method: 'PUT',
        body: JSON.stringify(updatedSettings),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        setSettings(updatedSettings);
      } else {
        console.error('Failed to update settings:', await response.text());
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to update settings'));
      console.error('Error updating clock settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ClockSettingsContext.Provider value={{ settings, isLoading, error, updateSettings }}>
      {children}
    </ClockSettingsContext.Provider>
  );
};