import React, { createContext, useContext, useEffect, useState } from 'react';

// Temporary default user ID (in a real app, this would come from authentication)
const DEFAULT_USER_ID = 1;

interface Alarm {
  id: number;
  userId: number;
  time: string; // Format: "HH:MM"
  label: string;
  days: string; // Format: "0,1,2,3,4,5,6" representing days of week
  enabled: boolean;
  createdAt: string;
}

interface NewAlarm {
  userId: number;
  time: string;
  label: string;
  days: string;
  enabled: boolean;
}

interface AlarmContextType {
  alarms: Alarm[];
  isLoading: boolean;
  error: Error | null;
  addAlarm: (alarm: NewAlarm) => Promise<void>;
  updateAlarm: (id: number, alarm: Partial<NewAlarm>) => Promise<void>;
  deleteAlarm: (id: number) => Promise<void>;
  toggleAlarm: (id: number, enabled: boolean) => Promise<void>;
}

const AlarmContext = createContext<AlarmContextType>({
  alarms: [],
  isLoading: false,
  error: null,
  addAlarm: async () => {},
  updateAlarm: async () => {},
  deleteAlarm: async () => {},
  toggleAlarm: async () => {},
});

export const useAlarms = () => useContext(AlarmContext);

export const AlarmProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  // Fetch alarms on mount
  useEffect(() => {
    const fetchAlarms = async () => {
      try {
        setIsLoading(true);
        
        try {
          const response = await fetch(`/api/alarms/${DEFAULT_USER_ID}`);
          if (response.ok) {
            const data = await response.json();
            setAlarms(data);
          } else {
            // If alarms don't exist yet, we'll use an empty array and not show an error
            console.log('No alarms found, using empty array');
          }
        } catch (err) {
          // API endpoint might not exist yet, so we'll use a default empty array
          console.log('Using default empty alarms array');
        }
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch alarms'));
        console.error('Error fetching alarms:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAlarms();
  }, []);

  const addAlarm = async (alarm: NewAlarm) => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/alarms', {
        method: 'POST',
        body: JSON.stringify(alarm),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setAlarms([...alarms, data]);
      } else {
        console.error('Failed to add alarm:', await response.text());
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to add alarm'));
      console.error('Error adding alarm:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const updateAlarm = async (id: number, updateData: Partial<NewAlarm>) => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/alarms/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setAlarms(alarms.map(alarm => alarm.id === id ? data : alarm));
      } else {
        console.error('Failed to update alarm:', await response.text());
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to update alarm'));
      console.error('Error updating alarm:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteAlarm = async (id: number) => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/alarms/${id}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setAlarms(alarms.filter(alarm => alarm.id !== id));
      } else {
        console.error('Failed to delete alarm:', await response.text());
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to delete alarm'));
      console.error('Error deleting alarm:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleAlarm = async (id: number, enabled: boolean) => {
    await updateAlarm(id, { enabled });
  };

  return (
    <AlarmContext.Provider 
      value={{ alarms, isLoading, error, addAlarm, updateAlarm, deleteAlarm, toggleAlarm }}
    >
      {children}
    </AlarmContext.Provider>
  );
};