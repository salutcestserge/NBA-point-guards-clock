import React, { createContext, useContext, useEffect } from 'react';
import { useClockSettings } from './ClockSettingsContext';

// Create a context for dark mode
const DarkModeContext = createContext<{ isDarkMode: boolean }>({
  isDarkMode: false
});

export const useDarkMode = () => useContext(DarkModeContext);

export const DarkModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings } = useClockSettings();
  const isDarkMode = settings.darkMode || false;
  
  // Apply dark mode class to html element
  useEffect(() => {
    const htmlElement = document.documentElement;
    
    if (isDarkMode) {
      htmlElement.classList.add('dark');
    } else {
      htmlElement.classList.remove('dark');
    }
    
    // Update CSS variables or other dark mode related settings
    if (isDarkMode) {
      document.body.style.backgroundColor = '#1a1a1a';
      document.body.style.color = '#ffffff';
    } else {
      document.body.style.backgroundColor = '#ffffff';
      document.body.style.color = '#1a1a1a';
    }
    
    return () => {
      // Cleanup
      htmlElement.classList.remove('dark');
    };
  }, [isDarkMode]);
  
  return (
    <DarkModeContext.Provider value={{ isDarkMode }}>
      {children}
    </DarkModeContext.Provider>
  );
};