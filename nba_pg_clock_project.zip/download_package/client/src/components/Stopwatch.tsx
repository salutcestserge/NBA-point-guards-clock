import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Pause, RotateCcw, Flag } from "lucide-react";
import { formatDuration } from "@/lib/utils";

export default function Stopwatch() {
  const [isRunning, setIsRunning] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  
  // Create a ref to store the interval ID
  const intervalRef = useRef<number | null>(null);
  
  // Start/pause the stopwatch
  const toggleStopwatch = () => {
    if (isRunning) {
      // Pause the stopwatch
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    } else {
      // Start the stopwatch
      const startTime = Date.now() - elapsedTime * 1000;
      
      intervalRef.current = window.setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
      }, 10) as unknown as number;
    }
    
    setIsRunning(!isRunning);
  };
  
  // Reset the stopwatch
  const resetStopwatch = () => {
    // Clear the interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    
    // Reset state
    setIsRunning(false);
    setElapsedTime(0);
    setLaps([]);
  };
  
  // Add a lap
  const addLap = () => {
    if (isRunning) {
      setLaps([...laps, elapsedTime]);
    }
  };
  
  // Format the time in MM:SS.ms format
  const formatStopwatchTime = (timeInSeconds: number) => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    const milliseconds = Math.floor((timeInSeconds * 100) % 100);
    
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(2, '0')}`;
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-oswald font-semibold">STOPWATCH</h2>
      
      <Card className="border border-gray-200 bg-white shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col items-center">
            {/* Stopwatch display */}
            <div className="text-5xl font-mono font-semibold mb-8 tracking-wider">
              {formatStopwatchTime(elapsedTime)}
            </div>
            
            {/* Controls */}
            <div className="flex gap-4 mb-6">
              <Button 
                variant="outline" 
                size="lg"
                onClick={toggleStopwatch}
                className={`w-24 ${isRunning ? "bg-gray-100" : ""}`}
              >
                {isRunning ? <Pause className="h-5 w-5 mr-1" /> : <Play className="h-5 w-5 mr-1" />}
                {isRunning ? "Pause" : "Start"}
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={resetStopwatch}
                className="w-24"
                disabled={elapsedTime === 0}
              >
                <RotateCcw className="h-5 w-5 mr-1" />
                Reset
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={addLap}
                disabled={!isRunning}
                className="w-24"
              >
                <Flag className="h-5 w-5 mr-1" />
                Lap
              </Button>
            </div>
            
            {/* Laps */}
            {laps.length > 0 && (
              <div className="w-full max-h-64 overflow-y-auto border border-gray-200 rounded-md">
                <div className="p-4">
                  <h3 className="text-lg font-medium mb-2">Laps</h3>
                  <ul className="space-y-2">
                    {laps.map((lapTime, index) => {
                      // Calculate lap interval (time since last lap)
                      const prevLapTime = index > 0 ? laps[index - 1] : 0;
                      const interval = lapTime - prevLapTime;
                      
                      return (
                        <li key={index} className="flex justify-between items-center py-1 border-b border-gray-100 last:border-0">
                          <span className="font-medium">Lap {laps.length - index}</span>
                          <div className="text-right">
                            <div className="font-mono">{formatStopwatchTime(lapTime)}</div>
                            <div className="text-xs text-gray-500 font-mono">+{formatStopwatchTime(interval)}</div>
                          </div>
                        </li>
                      );
                    }).reverse()}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}