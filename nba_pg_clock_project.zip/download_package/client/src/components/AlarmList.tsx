import { useState } from "react";
import { useAlarms } from "@/contexts/AlarmContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, Bell, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Define the Alarm type that we'll use in our components
// This makes TypeScript happy by treating createdAt as a string
interface AlarmData {
  id: number;
  userId: number | null;
  time: string;
  label: string;
  days: string;
  enabled: boolean | null;
  createdAt: string | Date;
}

const days = [
  { id: "0", label: "Sun" },
  { id: "1", label: "Mon" },
  { id: "2", label: "Tue" },
  { id: "3", label: "Wed" },
  { id: "4", label: "Thu" },
  { id: "5", label: "Fri" },
  { id: "6", label: "Sat" },
];

// Component to display and manage alarms
export default function AlarmList() {
  const { alarms, isLoading, addAlarm, updateAlarm, deleteAlarm, toggleAlarm } = useAlarms();
  const [showNewAlarmForm, setShowNewAlarmForm] = useState(false);
  const { toast } = useToast();
  
  // New alarm form state
  const [newAlarmTime, setNewAlarmTime] = useState("07:30");
  const [newAlarmLabel, setNewAlarmLabel] = useState("Wake up");
  const [selectedDays, setSelectedDays] = useState<string[]>(["1", "2", "3", "4", "5"]);

  const handleDayToggle = (day: string) => {
    if (selectedDays.includes(day)) {
      setSelectedDays(selectedDays.filter(d => d !== day));
    } else {
      setSelectedDays([...selectedDays, day]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedDays.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one day",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await addAlarm({
        userId: 1, // Default user
        time: newAlarmTime,
        label: newAlarmLabel,
        days: selectedDays.join(","),
        enabled: true
      });
      
      // Reset form
      setNewAlarmTime("07:30");
      setNewAlarmLabel("Wake up");
      setSelectedDays(["1", "2", "3", "4", "5"]);
      setShowNewAlarmForm(false);
      
      toast({
        title: "Alarm created",
        description: `Alarm set for ${newAlarmTime}`,
      });
    } catch (error) {
      toast({
        title: "Error creating alarm",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteAlarm = async (id: number) => {
    try {
      await deleteAlarm(id);
      toast({
        title: "Alarm deleted",
        description: "The alarm has been removed"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not delete the alarm",
        variant: "destructive"
      });
    }
  };

  const handleToggleAlarm = async (id: number, enabled: boolean) => {
    try {
      await toggleAlarm(id, enabled);
      toast({
        title: enabled ? "Alarm enabled" : "Alarm disabled",
        description: enabled ? "The alarm is now active" : "The alarm is now inactive"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not update the alarm",
        variant: "destructive"
      });
    }
  };

  const formatDays = (daysString: string) => {
    const dayIndices = daysString.split(",");
    
    if (dayIndices.length === 7) return "Every day";
    if (dayIndices.length === 5 && 
        ["1", "2", "3", "4", "5"].every(day => dayIndices.includes(day))) {
      return "Weekdays";
    }
    if (dayIndices.length === 2 && 
        ["0", "6"].every(day => dayIndices.includes(day))) {
      return "Weekends";
    }
    
    return dayIndices
      .map(index => days.find(d => d.id === index)?.label)
      .join(", ");
  };

  if (isLoading) {
    return <div className="flex justify-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-nba-blue"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-oswald font-semibold">ALARMS</h2>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => setShowNewAlarmForm(!showNewAlarmForm)}
        >
          {showNewAlarmForm ? "Cancel" : (
            <>
              <Plus className="h-4 w-4 mr-1" />
              Add Alarm
            </>
          )}
        </Button>
      </div>
      
      {showNewAlarmForm && (
        <Card className="border border-gray-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">New Alarm</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="alarmTime">Time</Label>
                  <Input 
                    id="alarmTime" 
                    type="time" 
                    value={newAlarmTime}
                    onChange={(e) => setNewAlarmTime(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="alarmLabel">Label</Label>
                  <Input 
                    id="alarmLabel" 
                    placeholder="Alarm label" 
                    value={newAlarmLabel}
                    onChange={(e) => setNewAlarmLabel(e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Repeat</Label>
                <div className="flex flex-wrap gap-2 pt-1">
                  {days.map((day) => (
                    <div key={day.id} className="flex items-center space-x-1">
                      <Checkbox 
                        id={`day-${day.id}`} 
                        checked={selectedDays.includes(day.id)}
                        onCheckedChange={() => handleDayToggle(day.id)}
                      />
                      <Label 
                        htmlFor={`day-${day.id}`}
                        className="text-sm font-normal cursor-pointer"
                      >
                        {day.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end pt-2">
                <Button type="submit">
                  <Bell className="h-4 w-4 mr-1" />
                  Save Alarm
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
      
      {alarms.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          No alarms set. Add your first alarm to get started.
        </div>
      ) : (
        <div className="space-y-3">
          {alarms.map((alarm) => (
            <AlarmItem 
              key={alarm.id} 
              alarm={alarm} 
              onDelete={handleDeleteAlarm}
              onToggle={handleToggleAlarm}
              formatDays={formatDays}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Individual alarm item component
interface AlarmItemProps {
  alarm: AlarmData;
  onDelete: (id: number) => void;
  onToggle: (id: number, enabled: boolean) => void;
  formatDays: (days: string) => string;
}

function AlarmItem({ alarm, onDelete, onToggle, formatDays }: AlarmItemProps) {
  // Format time for display
  const formatTime = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(":");
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium">{formatTime(alarm.time)}</h3>
          <p className="text-sm text-gray-600">{alarm.label}</p>
          <p className="text-xs text-gray-500 mt-1">{formatDays(alarm.days)}</p>
        </div>
        <div className="flex items-center space-x-3">
          <Switch 
            checked={alarm.enabled || false}
            onCheckedChange={(checked) => onToggle(alarm.id, checked)}
          />
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onDelete(alarm.id)}
            className="text-gray-500 hover:text-red-500"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}