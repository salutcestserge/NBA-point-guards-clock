import React, { useState } from 'react';
import { useClockSettings } from '@/contexts/ClockSettingsContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import SoundSettings from './SoundSettings';

const ClockSettings = () => {
  const { settings, updateSettings, isLoading } = useClockSettings();
  
  // Local state for the form
  const [clockColor, setClockColor] = useState(settings.clockColor);
  const [hourHandColor, setHourHandColor] = useState(settings.hourHandColor);
  const [minuteHandColor, setMinuteHandColor] = useState(settings.minuteHandColor);
  const [secondHandColor, setSecondHandColor] = useState(settings.secondHandColor);
  const [use24HourFormat, setUse24HourFormat] = useState(settings.use24HourFormat);
  const [showSeconds, setShowSeconds] = useState(settings.showSeconds);
  const [darkMode, setDarkMode] = useState(settings.darkMode || false);
  
  // Predefined themes
  const themes = [
    { name: "Default", colors: { clock: "#343A40", hour: "#1E40AF", minute: "#343A40", second: "#DC2626" } },
    { name: "Lakers", colors: { clock: "#552583", hour: "#FDB927", minute: "#552583", second: "#FDB927" } },
    { name: "Bulls", colors: { clock: "#CE1141", hour: "#000000", minute: "#CE1141", second: "#000000" } },
    { name: "Celtics", colors: { clock: "#007A33", hour: "#BA9653", minute: "#007A33", second: "#FFFFFF" } },
    { name: "Heat", colors: { clock: "#98002E", hour: "#F9A01B", minute: "#98002E", second: "#000000" } },
    { name: "Mavericks", colors: { clock: "#00538C", hour: "#B8C4CA", minute: "#00538C", second: "#002B5E" } },
  ];
  
  // Apply a theme
  const applyTheme = (theme: { clock: string; hour: string; minute: string; second: string }) => {
    setClockColor(theme.clock);
    setHourHandColor(theme.hour);
    setMinuteHandColor(theme.minute);
    setSecondHandColor(theme.second);
  };
  
  // Save settings
  const saveSettings = async () => {
    await updateSettings({
      clockColor,
      hourHandColor,
      minuteHandColor,
      secondHandColor,
      use24HourFormat,
      showSeconds,
      darkMode
    });
  };
  
  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Clock Settings</CardTitle>
        <CardDescription>
          Customize your NBA Point Guard Clock appearance and behavior
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="themes" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="themes">Themes</TabsTrigger>
            <TabsTrigger value="custom">Custom Colors</TabsTrigger>
            <TabsTrigger value="sounds">Sounds</TabsTrigger>
          </TabsList>
          
          <TabsContent value="themes" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {themes.map((theme) => (
                <div 
                  key={theme.name}
                  className="border rounded-lg p-2 cursor-pointer hover:border-blue-500 transition-colors"
                  onClick={() => applyTheme(theme.colors)}
                >
                  <div className="flex justify-center items-center mb-2">
                    <div
                      className="w-16 h-16 rounded-full border-4"
                      style={{ borderColor: theme.colors.clock }}
                    >
                      <div className="relative w-full h-full">
                        <div className="absolute top-1/2 left-1/2 w-1 h-5 -ml-0.5 -mt-1.5 origin-bottom transform rotate-45"
                             style={{ backgroundColor: theme.colors.hour }}></div>
                        <div className="absolute top-1/2 left-1/2 w-1 h-6 -ml-0.5 -mt-3 origin-bottom transform rotate-90"
                             style={{ backgroundColor: theme.colors.minute }}></div>
                        <div className="absolute top-1/2 left-1/2 w-0.5 h-7 -ml-0.5 -mt-4 origin-bottom transform rotate-180"
                             style={{ backgroundColor: theme.colors.second }}></div>
                      </div>
                    </div>
                  </div>
                  <div className="text-center font-medium text-sm">{theme.name}</div>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="custom" className="space-y-4 pt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="clockColor">Clock Color</Label>
                <div className="flex gap-2">
                  <div 
                    className="w-10 h-10 rounded border"
                    style={{ backgroundColor: clockColor }}
                  ></div>
                  <Input 
                    id="clockColor" 
                    type="text" 
                    value={clockColor} 
                    onChange={(e) => setClockColor(e.target.value)}
                  />
                  <Input 
                    type="color" 
                    value={clockColor} 
                    onChange={(e) => setClockColor(e.target.value)}
                    className="w-10 p-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="hourHandColor">Hour Hand Color</Label>
                <div className="flex gap-2">
                  <div 
                    className="w-10 h-10 rounded border"
                    style={{ backgroundColor: hourHandColor }}
                  ></div>
                  <Input 
                    id="hourHandColor" 
                    type="text" 
                    value={hourHandColor} 
                    onChange={(e) => setHourHandColor(e.target.value)}
                  />
                  <Input 
                    type="color" 
                    value={hourHandColor} 
                    onChange={(e) => setHourHandColor(e.target.value)}
                    className="w-10 p-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="minuteHandColor">Minute Hand Color</Label>
                <div className="flex gap-2">
                  <div 
                    className="w-10 h-10 rounded border"
                    style={{ backgroundColor: minuteHandColor }}
                  ></div>
                  <Input 
                    id="minuteHandColor" 
                    type="text" 
                    value={minuteHandColor} 
                    onChange={(e) => setMinuteHandColor(e.target.value)}
                  />
                  <Input 
                    type="color" 
                    value={minuteHandColor} 
                    onChange={(e) => setMinuteHandColor(e.target.value)}
                    className="w-10 p-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="secondHandColor">Second Hand Color</Label>
                <div className="flex gap-2">
                  <div 
                    className="w-10 h-10 rounded border"
                    style={{ backgroundColor: secondHandColor }}
                  ></div>
                  <Input 
                    id="secondHandColor" 
                    type="text" 
                    value={secondHandColor} 
                    onChange={(e) => setSecondHandColor(e.target.value)}
                  />
                  <Input 
                    type="color" 
                    value={secondHandColor} 
                    onChange={(e) => setSecondHandColor(e.target.value)}
                    className="w-10 p-1"
                  />
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="sounds" className="pt-4">
            <SoundSettings />
          </TabsContent>
        </Tabs>
        
        <div className="space-y-4 mt-6 pt-6 border-t">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="showSeconds" className="font-medium text-sm">Show Seconds Hand</Label>
              <p className="text-sm text-gray-500">Show or hide the second hand on the clock</p>
            </div>
            <Switch 
              id="showSeconds" 
              checked={showSeconds}
              onCheckedChange={setShowSeconds}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="use24HourFormat" className="font-medium text-sm">Use 24 Hour Format</Label>
              <p className="text-sm text-gray-500">Display time in 24-hour format (military time)</p>
            </div>
            <Switch 
              id="use24HourFormat" 
              checked={use24HourFormat}
              onCheckedChange={setUse24HourFormat}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="darkMode" className="font-medium text-sm">Dark Mode</Label>
              <p className="text-sm text-gray-500">Switch between light and dark theme</p>
            </div>
            <Switch 
              id="darkMode" 
              checked={darkMode}
              onCheckedChange={setDarkMode}
            />
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={() => {
            setClockColor(settings.clockColor);
            setHourHandColor(settings.hourHandColor);
            setMinuteHandColor(settings.minuteHandColor);
            setSecondHandColor(settings.secondHandColor);
            setUse24HourFormat(settings.use24HourFormat);
            setShowSeconds(settings.showSeconds);
            setDarkMode(settings.darkMode || false);
          }}
        >
          Reset
        </Button>
        <Button onClick={saveSettings} disabled={isLoading}>
          {isLoading ? 'Saving...' : 'Save Settings'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ClockSettings;