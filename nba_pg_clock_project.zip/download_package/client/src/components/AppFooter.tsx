import { useClockSettings } from "@/contexts/ClockSettingsContext";

export default function AppFooter() {
  const { settings } = useClockSettings();
  
  return (
    <footer className={`mt-8 py-4 text-center text-xs ${settings.darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
      <div className="container mx-auto px-4">
        <p className="mb-2">© {new Date().getFullYear()} NBA Point Guard Clock. All rights reserved.</p>
        <div className="flex justify-center space-x-4">
          <a 
            href="/privacy-policy.html" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:underline"
          >
            Privacy Policy
          </a>
          <a 
            href="/terms-of-service.html" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:underline"
          >
            Terms of Service
          </a>
        </div>
      </div>
    </footer>
  );
}