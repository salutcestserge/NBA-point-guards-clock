import { useState } from "react";
import { useTimers } from "@/contexts/TimerContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Play, Pause, Plus, Timer as TimerIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDuration } from "@/lib/utils";

// Define the Timer type to use in components
interface TimerData {
  id: number;
  userId: number | null;
  duration: number; // in seconds
  label: string;
  createdAt: string | Date;
}

// Component to display and manage timers
export default function TimerList() {
  const { timers, isLoading, addTimer, updateTimer, deleteTimer } = useTimers();
  const [showNewTimerForm, setShowNewTimerForm] = useState(false);
  const { toast } = useToast();
  
  // Active timer state
  const [activeTimers, setActiveTimers] = useState<Record<number, boolean>>({});
  const [remainingTimes, setRemainingTimes] = useState<Record<number, number>>({});
  
  // New timer form state
  const [newTimerHours, setNewTimerHours] = useState(0);
  const [newTimerMinutes, setNewTimerMinutes] = useState(10);
  const [newTimerSeconds, setNewTimerSeconds] = useState(0);
  const [newTimerLabel, setNewTimerLabel] = useState("Timer");

  // Handle starting a timer
  const handleStartTimer = (timer: TimerData) => {
    const timerId = timer.id;
    
    // If timer is not active, start it and set initial remaining time
    if (!activeTimers[timerId]) {
      setActiveTimers(prev => ({ ...prev, [timerId]: true }));
      
      // If no remaining time is set, use the original duration
      if (!remainingTimes[timerId]) {
        setRemainingTimes(prev => ({ ...prev, [timerId]: timer.duration }));
      }
      
      // Start the timer
      const intervalId = setInterval(() => {
        setRemainingTimes(prev => {
          const newTime = Math.max(0, prev[timerId] - 1);
          
          // If timer reaches 0, clear interval and set timer to inactive
          if (newTime === 0) {
            clearInterval(window.timers?.[timerId]);
            delete window.timers?.[timerId];
            
            // Show a toast notification
            toast({
              title: `Timer Complete: ${timer.label}`,
              description: "Your timer has finished!",
            });
            
            // Set timer to inactive
            setActiveTimers(active => ({ ...active, [timerId]: false }));
          }
          
          return { ...prev, [timerId]: newTime };
        });
      }, 1000);
      
      // Store interval ID in window object
      if (!window.timers) window.timers = {};
      window.timers[timerId] = intervalId as unknown as number;
    } else {
      // If timer is active, pause it
      clearInterval(window.timers?.[timerId]);
      delete window.timers?.[timerId];
      setActiveTimers(prev => ({ ...prev, [timerId]: false }));
    }
  };

  // Reset timer
  const handleResetTimer = (timer: TimerData) => {
    const timerId = timer.id;
    
    // Clear the interval
    if (window.timers?.[timerId]) {
      clearInterval(window.timers[timerId]);
      delete window.timers[timerId];
    }
    
    // Reset states
    setActiveTimers(prev => ({ ...prev, [timerId]: false }));
    setRemainingTimes(prev => ({ ...prev, [timerId]: timer.duration }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const totalSeconds = 
      (newTimerHours * 3600) + 
      (newTimerMinutes * 60) + 
      newTimerSeconds;
      
    if (totalSeconds <= 0) {
      toast({
        title: "Error",
        description: "Timer duration must be greater than 0",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const newTimer = await addTimer({
        userId: 1, // Default user
        duration: totalSeconds,
        label: newTimerLabel
      });
      
      // Initialize remaining time for this timer
      if (newTimer && typeof newTimer === 'object' && 'id' in newTimer) {
        setRemainingTimes(prev => ({ ...prev, [newTimer.id]: totalSeconds }));
      }
      
      // Reset form
      setNewTimerHours(0);
      setNewTimerMinutes(10);
      setNewTimerSeconds(0);
      setNewTimerLabel("Timer");
      setShowNewTimerForm(false);
      
      toast({
        title: "Timer created",
        description: `New timer: ${newTimerLabel} (${formatDuration(totalSeconds)})`,
      });
    } catch (error) {
      toast({
        title: "Error creating timer",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteTimer = async (id: number) => {
    try {
      // Clear any running interval
      if (window.timers?.[id]) {
        clearInterval(window.timers[id]);
        delete window.timers[id];
      }
      
      await deleteTimer(id);
      
      // Clean up state
      setActiveTimers(prev => {
        const newState = { ...prev };
        delete newState[id];
        return newState;
      });
      
      setRemainingTimes(prev => {
        const newState = { ...prev };
        delete newState[id];
        return newState;
      });
      
      toast({
        title: "Timer deleted",
        description: "The timer has been removed"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not delete the timer",
        variant: "destructive"
      });
    }
  };
  
  // Cleanup on unmount
  window.addEventListener('beforeunload', () => {
    if (window.timers) {
      Object.values(window.timers).forEach(intervalId => {
        clearInterval(intervalId as number);
      });
    }
  });

  if (isLoading) {
    return <div className="flex justify-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-nba-blue"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-oswald font-semibold">TIMERS</h2>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => setShowNewTimerForm(!showNewTimerForm)}
        >
          {showNewTimerForm ? "Cancel" : (
            <>
              <Plus className="h-4 w-4 mr-1" />
              Add Timer
            </>
          )}
        </Button>
      </div>
      
      {showNewTimerForm && (
        <Card className="border border-gray-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">New Timer</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-4 gap-2">
                <div className="space-y-2">
                  <Label htmlFor="timerHours">Hours</Label>
                  <Input 
                    id="timerHours" 
                    type="number" 
                    min="0"
                    max="23"
                    value={newTimerHours}
                    onChange={(e) => setNewTimerHours(parseInt(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timerMinutes">Minutes</Label>
                  <Input 
                    id="timerMinutes" 
                    type="number"
                    min="0"
                    max="59" 
                    value={newTimerMinutes}
                    onChange={(e) => setNewTimerMinutes(parseInt(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timerSeconds">Seconds</Label>
                  <Input 
                    id="timerSeconds" 
                    type="number"
                    min="0"
                    max="59" 
                    value={newTimerSeconds}
                    onChange={(e) => setNewTimerSeconds(parseInt(e.target.value) || 0)}
                  />
                </div>
                <div className="space-y-2 col-span-1">
                  <Label htmlFor="timerLabel">Label</Label>
                  <Input 
                    id="timerLabel" 
                    placeholder="Timer label" 
                    value={newTimerLabel}
                    onChange={(e) => setNewTimerLabel(e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="flex justify-end pt-2">
                <Button type="submit">
                  <TimerIcon className="h-4 w-4 mr-1" />
                  Save Timer
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
      
      {timers.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          No timers set. Add your first timer to get started.
        </div>
      ) : (
        <div className="space-y-3">
          {timers.map((timer) => (
            <TimerItem 
              key={timer.id} 
              timer={timer} 
              onDelete={handleDeleteTimer}
              onToggle={handleStartTimer}
              onReset={handleResetTimer}
              isActive={activeTimers[timer.id] || false}
              remainingTime={remainingTimes[timer.id] !== undefined ? remainingTimes[timer.id] : timer.duration}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// Timer item component
interface TimerItemProps {
  timer: TimerData;
  onDelete: (id: number) => void;
  onToggle: (timer: TimerData) => void;
  onReset: (timer: TimerData) => void;
  isActive: boolean;
  remainingTime: number;
}

function TimerItem({ timer, onDelete, onToggle, onReset, isActive, remainingTime }: TimerItemProps) {
  const progress = (remainingTime / timer.duration) * 100;
  
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-4">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h3 className="text-lg font-medium">{timer.label}</h3>
          <p className="text-sm text-gray-600">{formatDuration(remainingTime)}</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onToggle(timer)}
            className={isActive ? "bg-gray-100" : ""}
          >
            {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onReset(timer)}
          >
            Reset
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onDelete(timer.id)}
            className="text-gray-500 hover:text-red-500"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Progress bar */}
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className="bg-blue-600 h-2.5 rounded-full transition-all duration-1000" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    </div>
  );
}

// Add timers property to Window interface
declare global {
  interface Window {
    timers?: Record<number, number>;
  }
}