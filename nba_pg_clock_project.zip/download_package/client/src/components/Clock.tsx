import { useRef, useEffect, useState } from "react";
import html2canvas from "html2canvas";
import { PointGuard } from "@shared/schema";
import ClockHand from "./ClockHand";
import PointGuardMarker from "./PointGuardMarker";
import { useClockSettings } from "@/contexts/ClockSettingsContext";
import { teamColors } from "@/lib/teamColors";

interface ClockProps {
  time: Date;
  pointGuards: PointGuard[];
}

const Clock = ({ time, pointGuards }: ClockProps) => {
  const clockRef = useRef<HTMLDivElement>(null);
  // Get theme settings
  const { settings } = useClockSettings();
  
  // State to track current and next hour for mascot display
  const [currentHour, setCurrentHour] = useState<number>(0);
  const [nextHour, setNextHour] = useState<number>(0);
  
  // Add method to export the clock as image
  const exportClockAsImage = async () => {
    if (!clockRef.current) return null;
    
    const canvas = await html2canvas(clockRef.current, {
      backgroundColor: null,
      scale: 2,
    });
    
    return canvas.toDataURL("image/png");
  };
  
  // Expose the export method to window for DownloadOptions component
  useEffect(() => {
    (window as any).exportClockAsImage = exportClockAsImage;
    
    return () => {
      delete (window as any).exportClockAsImage;
    };
  }, []);
  
  // Update current and next hour for mascot display
  useEffect(() => {
    // Get the current hour (1-12)
    const hour = time.getHours() % 12 || 12;
    setCurrentHour(hour);
    
    // Calculate the next hour (wrapping around from 12 to 1)
    const next = (hour % 12) + 1;
    setNextHour(next);
  }, [time]);
  
  // Calculate hours, minutes, seconds for hands
  const hours = time.getHours() % 12 || 12; // Make sure 12 o'clock is displayed as 12, not 0
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();
  
  // Format time string based on settings
  const timeString = settings.use24HourFormat 
    ? time.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second: settings.showSeconds ? '2-digit' : undefined, hour12: false})
    : time.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second: settings.showSeconds ? '2-digit' : undefined, hour12: true});
  
  // Calculate degrees for the hands
  const hourDegrees = (hours * 30) + (minutes * 0.5); // 30 degrees per hour + small adjustment for minutes
  const minuteDegrees = minutes * 6; // 6 degrees per minute
  const secondDegrees = seconds * 6; // 6 degrees per second
  
  // Get current team and its colors
  const currentTeam = pointGuards.find(pg => pg.position === currentHour)?.team || '';
  const teamColor = currentTeam ? teamColors[currentTeam]?.primary : '';
  const teamColorSecondary = currentTeam ? teamColors[currentTeam]?.secondary : '';
  
  // Apply custom styling from theme settings with team colors as background
  const clockStyle = {
    '--clock-color': settings.clockColor,
    borderColor: settings.clockColor,
    background: currentTeam && teamColor ? 
      `radial-gradient(circle, ${settings.darkMode ? 'rgba(30, 30, 30, 0.9)' : 'rgba(255, 255, 255, 0.95)'} 30%, ${teamColor}40 70%, ${teamColor}80 100%)` : 
      (settings.darkMode ? '#1a1a1a' : 'white'),
    transition: 'background 0.5s ease-in-out',
  } as React.CSSProperties;
  
  return (
    <div className="clock-wrapper">
      <div 
        ref={clockRef}
        className={`clock-container border-8 rounded-full shadow-lg ${settings.darkMode ? 'bg-gray-900' : 'bg-white'}`}
        id="clock-face"
        style={clockStyle}
      >
        <div className="clock-face">
          {/* Numbers for clock positions (optional) */}
          {[...Array(12)].map((_, i) => {
            const hourPosition = i + 1;
            const angle = (hourPosition * 30) - 90; // 30 degrees per hour, starting at -90 (12 o'clock)
            const radians = angle * (Math.PI / 180);
            // Position numbers slightly outside player markers
            const x = 50 + 47 * Math.cos(radians);
            const y = 50 + 47 * Math.sin(radians);
            
            return (
              <div 
                key={`number-${hourPosition}`}
                className="clock-number"
                style={{ 
                  left: `${x}%`, 
                  top: `${y}%`,
                  transform: 'translate(-50%, -50%)',
                  color: settings.darkMode ? 'white' : settings.clockColor, 
                  fontWeight: 'bold',
                  fontSize: '0.8rem',
                  position: 'absolute',
                  textShadow: settings.darkMode ? '0 0 3px rgba(0,0,0,0.5)' : 'none'
                }}
              >
                {hourPosition}
              </div>
            );
          })}
          
          {/* Position markers for 12 player positions */}
          {[...Array(12)].map((_, i) => {
            const hourPosition = i + 1;
            const player = pointGuards.find(pg => pg.position === hourPosition);
            const angle = (hourPosition * 30) - 90; // 30 degrees per hour, starting at -90 (12 o'clock)
            const radians = angle * (Math.PI / 180);
            // Position players in a circle around the clock at a fixed radius from center
            // The distance percentage controls how far from center the players appear
            const x = 50 + 40 * Math.cos(radians); 
            const y = 50 + 40 * Math.sin(radians);
            
            return (
              <PointGuardMarker
                key={hourPosition}
                position={{ x, y }}
                player={player}
                hourPosition={hourPosition}
              />
            );
          })}
          
          {/* Clock Hands */}
          <ClockHand 
            type="hour" 
            degrees={hourDegrees} 
            color={settings.hourHandColor}
          />
          <ClockHand 
            type="minute" 
            degrees={minuteDegrees} 
            color={settings.minuteHandColor}
          />
          {settings.showSeconds && (
            <ClockHand 
              type="second" 
              degrees={secondDegrees} 
              color={settings.secondHandColor}
            />
          )}
          
          {/* No center decoration - removed for clean design */}
          
          {/* Center dot */}
          <div 
            className="clock-center"
            style={{ backgroundColor: settings.clockColor }}
          ></div>
        </div>
      </div>
      
      {/* Digital time display */}
      <div className="digital-time text-center mt-4 font-mono text-xl font-bold" 
           style={{ 
             color: settings.darkMode ? 'white' : settings.clockColor,
             textShadow: settings.darkMode ? '0 0 5px rgba(0,0,0,0.3)' : 'none'
           }}>
        {timeString}
      </div>
    </div>
  );
};

export default Clock;
