import { PointGuard } from "@shared/schema";
import { useClockSettings } from "@/contexts/ClockSettingsContext";

interface PointGuardMarkerProps {
  position: {
    x: number;
    y: number;
  };
  player?: PointGuard;
  hourPosition: number;
}

const PointGuardMarker = ({ position, player, hourPosition }: PointGuardMarkerProps) => {
  const { settings } = useClockSettings();

  return (
    <div
      className="player-marker"
      style={{
        left: `${position.x}%`,
        top: `${position.y}%`,
        borderColor: player ? settings.clockColor : 'transparent',
      }}
      title={player ? player.name : `${hourPosition} o'clock`}
    >
      {player ? (
        <>
          <img 
            src={player.imageUrl} 
            alt={player.name} 
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="player-tooltip bg-white p-3 rounded-lg shadow-xl text-xs">
            <div className="text-center mb-2 font-bold text-sm text-nba-blue">{player.name}</div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col">
                <span className="text-gray-600 text-xs">Team</span>
                <span className="font-medium">{player.team}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-600 text-xs">Jersey</span>
                <span className="font-medium">#{player.jerseyNumber}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-600 text-xs">PPG</span>
                <span className="font-medium">{player.ppg}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-600 text-xs">APG</span>
                <span className="font-medium">{player.apg}</span>
              </div>
            </div>
            <div className="mt-2 pt-2 text-center text-xs text-gray-600 border-t border-gray-100">
              {player.achievements}
            </div>
          </div>
        </>
      ) : (
        <div className="w-full h-full bg-gray-100 rounded-full flex items-center justify-center font-bold"
          style={{ color: settings.clockColor, fontSize: '14px' }}>
          {hourPosition}
        </div>
      )}
    </div>
  );
};

export default PointGuardMarker;
