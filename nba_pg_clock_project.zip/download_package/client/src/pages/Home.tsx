import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import AppHeader from "@/components/AppHeader";
import AppFooter from "@/components/AppFooter";
import Clock from "@/components/Clock";
import { PointGuard } from "@shared/schema";

export default function Home() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('clock');
  
  // Fetch point guard data
  const { data: pointGuards, isLoading, error } = useQuery<PointGuard[]>({
    queryKey: ['/api/pointguards'],
  });

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-oswald font-bold text-gray-800 text-center mb-2">
            NBA POINT GUARD CLOCK
          </h1>
          <p className="text-gray-600 text-center mb-6">
            Interactive clock featuring the 12 greatest NBA point guards of all time
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          {/* Simple Tab Navigation */}
          <div className="flex space-x-4 mb-6 border-b overflow-x-auto">
            <button 
              className={`px-4 py-2 font-medium ${activeTab === 'clock' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-600'}`}
              onClick={() => setActiveTab('clock')}
            >
              Clock
            </button>
            <button 
              className={`px-4 py-2 font-medium ${activeTab === 'info' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-600'}`}
              onClick={() => setActiveTab('info')}
            >
              Info
            </button>
            <button 
              className={`px-4 py-2 font-medium ${activeTab === 'download' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-600'}`}
              onClick={() => setActiveTab('download')}
            >
              Download
            </button>
          </div>
          
          {/* Tab Content */}
          {activeTab === 'clock' && (
            <div className="bg-gray-100 rounded-lg p-4 mb-4">
              <h2 className="text-xl font-bold mb-4">THE LEGENDS CLOCK</h2>
              
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : error ? (
                <div className="text-center text-red-500 p-4">
                  Error loading point guards. Please try again.
                </div>
              ) : (
                <div className="mx-auto max-w-[350px]">
                  <Clock 
                    time={currentTime} 
                    pointGuards={pointGuards || []} 
                  />
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'info' && (
            <div className="bg-gray-100 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">ABOUT THIS CLOCK</h2>
              <p className="text-gray-700 mb-4">
                This interactive clock features the 12 greatest NBA point guards of all time.
                Each point guard is positioned at their jersey number (when possible) or at a position
                that represents their place in basketball history.
              </p>
              
              <h3 className="font-medium text-gray-800 mb-2">How To Use:</h3>
              <ul className="list-disc pl-5 mb-4 text-gray-700 space-y-1">
                <li>Watch the clock hands move in real-time</li>
                <li>Hover over players to see their career information</li>
                <li>Customize the clock appearance</li>
                <li>Download for various platforms</li>
              </ul>
            </div>
          )}
          
          {activeTab === 'download' && (
            <div className="bg-gray-100 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">DOWNLOAD THE APP</h2>
              <p className="mb-6 text-gray-600">
                Available for iOS, Android, macOS, and Apple Watch.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <a 
                  href="https://apps.apple.com/app/nba-pg-clock/id123456789" 
                  target="_blank"
                  className="p-4 flex items-center justify-center border-2 rounded-lg hover:border-blue-500 transition-colors"
                >
                  <span className="font-bold">Download for iOS</span>
                </a>
                
                <a 
                  href="https://play.google.com/store/apps/details?id=com.nbapgclock" 
                  target="_blank"
                  className="p-4 flex items-center justify-center border-2 rounded-lg hover:border-green-500 transition-colors"
                >
                  <span className="font-bold">Download for Android</span>
                </a>
                
                <a 
                  href="https://apps.apple.com/app/nba-pg-clock-desktop/id987654321" 
                  target="_blank"
                  className="p-4 flex items-center justify-center border-2 rounded-lg hover:border-blue-500 transition-colors"
                >
                  <span className="font-bold">Download for macOS</span>
                </a>
                
                <a 
                  href="https://apps.apple.com/app/nba-pg-clock-watch/id543216789" 
                  target="_blank"
                  className="p-4 flex items-center justify-center border-2 rounded-lg hover:border-blue-500 transition-colors"
                >
                  <span className="font-bold">Download for Apple Watch</span>
                </a>
              </div>
              
              <div className="text-center mt-6">
                <button 
                  className="px-8 py-3 bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white rounded-md"
                  onClick={() => {
                    alert("To install this app on your device:\n\n• On iOS: Tap the share icon and then 'Add to Home Screen'\n• On Android: Tap the menu icon and then 'Add to Home Screen'\n• On Desktop: Click the install icon in the address bar");
                  }}
                >
                  Install Web App
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <AppFooter />
    </div>
  );
}
